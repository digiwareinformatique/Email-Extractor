import React, { useState, useEffect } from 'react';
import { 
  Layers, Play, Pause, Square, Plus, CheckCircle, Clock, AlertCircle, 
  RefreshCw, BarChart2, Eye, Filter, ArrowRight, Sparkles, Send, ShieldCheck
} from 'lucide-react';
import { MultiSegmentCampaign, MessageTemplate } from '../../types/businessCenter';
import { businessCenterApi } from '../../services/businessCenterApi';

export const CampaignsView: React.FC = () => {
  const [campaigns, setCampaigns] = useState<MultiSegmentCampaign[]>([]);
  const [templates, setTemplates] = useState<MessageTemplate[]>([]);
  const [selectedCampaign, setSelectedCampaign] = useState<MultiSegmentCampaign | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [actionFeedback, setActionFeedback] = useState<string | null>(null);

  // New Campaign Modal
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newCampaignName, setNewCampaignName] = useState('');
  const [newDailyGoal, setNewDailyGoal] = useState<number>(50);
  const [newDescription, setNewDescription] = useState('');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [cList, tList] = await Promise.all([
        businessCenterApi.getCampaigns(),
        businessCenterApi.getTemplates()
      ]);
      setCampaigns(cList);
      setTemplates(tList);
      if (cList.length > 0 && !selectedCampaign) {
        setSelectedCampaign(cList[0]);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handlePrepare = async (campId: string) => {
    setIsProcessing(true);
    setActionFeedback(null);
    try {
      const res = await businessCenterApi.prepareCampaign(campId);
      setActionFeedback(`✓ ${res.totalPrepared} jobs préparés et vérifiés selon les quotas par segment.`);
      loadData();
    } catch (err: any) {
      setActionFeedback(`Erreur : ${err.message}`);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleLaunch = async (campId: string) => {
    setIsProcessing(true);
    setActionFeedback(null);
    try {
      const res = await businessCenterApi.launchCampaign(campId);
      setActionFeedback(`🚀 Campagne active : ${res.dispatched} messages transmis au WhatsApp Sender.`);
      loadData();
    } catch (err: any) {
      setActionFeedback(`Erreur : ${err.message}`);
    } finally {
      setIsProcessing(false);
    }
  };

  const handlePause = async (campId: string) => {
    try {
      await businessCenterApi.pauseCampaign(campId);
      loadData();
    } catch (err) {
      console.error(err);
    }
  };

  const handleResume = async (campId: string) => {
    try {
      await businessCenterApi.resumeCampaign(campId);
      loadData();
    } catch (err) {
      console.error(err);
    }
  };

  const handleCreateCampaign = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCampaignName.trim()) return;

    try {
      const defaultAllocations = [
        {
          segment_id: 'AVOCAT',
          segment_name: 'Avocats & Juridique',
          template_id: templates[0]?.id || 'tmpl_1',
          template_name: templates[0]?.name || 'Template A',
          daily_quota: Math.round(newDailyGoal * 0.2),
          prepared_count: 0,
          sent_count: 0,
          delivered_count: 0,
          failed_count: 0
        },
        {
          segment_id: 'COMPTABLE',
          segment_name: 'Experts-Comptables',
          template_id: templates[1]?.id || 'tmpl_2',
          template_name: templates[1]?.name || 'Template B',
          daily_quota: Math.round(newDailyGoal * 0.4),
          prepared_count: 0,
          sent_count: 0,
          delivered_count: 0,
          failed_count: 0
        },
        {
          segment_id: 'ENTREPRISE',
          segment_name: 'Entreprises & Sociétés',
          template_id: templates[2]?.id || templates[0]?.id || 'tmpl_3',
          template_name: templates[2]?.name || 'Template C',
          daily_quota: Math.round(newDailyGoal * 0.4),
          prepared_count: 0,
          sent_count: 0,
          delivered_count: 0,
          failed_count: 0
        }
      ];

      await businessCenterApi.saveCampaign({
        name: newCampaignName.trim(),
        description: newDescription.trim(),
        objective: 'Prospection multicanale et fidélisation WhatsApp',
        status: 'DRAFT',
        daily_goal: newDailyGoal,
        segment_allocations: defaultAllocations,
        exclusions: {
          exclude_recent_contact_days: 15,
          exclude_opt_out: true,
          exclude_tags: ['Exclus']
        }
      });

      setIsModalOpen(false);
      setNewCampaignName('');
      loadData();
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="space-y-4">
      {/* Header bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 bg-slate-900/80 p-4 rounded-2xl border border-slate-800">
        <div>
          <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
            <Layers className="w-5 h-5 text-emerald-400" />
            Campagnes Multi-Segments & Multi-Templates
          </h2>
          <p className="text-xs text-slate-400">
            Orchestrez une campagne unique avec quotas par segments (ex: 50/jour = 10 Avocats + 20 Comptables + 20 Entreprises).
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all shadow-md self-start md:self-auto cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Nouvelle Campagne Multi-Segments</span>
        </button>
      </div>

      {actionFeedback && (
        <div className="p-3 bg-emerald-950/60 border border-emerald-500/40 text-emerald-200 rounded-xl text-xs flex items-center justify-between animate-in fade-in">
          <span>{actionFeedback}</span>
          <button onClick={() => setActionFeedback(null)} className="text-emerald-400 font-bold ml-2">×</button>
        </div>
      )}

      {/* Grid of campaigns */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Colonne gauche : liste des campagnes */}
        <div className="space-y-3">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider px-1">
            Campagnes Actives & Planifiées
          </h3>

          <div className="space-y-2">
            {campaigns.map(camp => {
              const isSelected = selectedCampaign?.id === camp.id;
              return (
                <div
                  key={camp.id}
                  onClick={() => setSelectedCampaign(camp)}
                  className={`p-3.5 rounded-xl border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-slate-800/90 border-emerald-500 shadow-md'
                      : 'bg-slate-900/60 border-slate-800 hover:bg-slate-800/40'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <h4 className="text-xs font-bold text-slate-100 truncate pr-2">
                      {camp.name}
                    </h4>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      camp.status === 'RUNNING' ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/30' :
                      camp.status === 'PAUSED' ? 'bg-amber-950 text-amber-300 border border-amber-500/30' :
                      camp.status === 'PREPARED' ? 'bg-blue-950 text-blue-300 border border-blue-500/30' :
                      'bg-slate-800 text-slate-400'
                    }`}>
                      {camp.status}
                    </span>
                  </div>

                  <p className="text-[11px] text-slate-400 line-clamp-2 mb-2">
                    {camp.description || 'Campagne multi-segments'}
                  </p>

                  <div className="flex items-center justify-between text-[11px] text-slate-400 pt-2 border-t border-slate-800/80">
                    <span>Objectif : <strong className="text-slate-200">{camp.daily_goal}/jour</strong></span>
                    <span>Transmis : <strong className="text-emerald-400">{camp.sent_jobs_count}</strong></span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Colonne droite : détail & orchestration de la campagne sélectionnée */}
        {selectedCampaign && (
          <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-5">
            {/* Header campagne */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
              <div>
                <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                  {selectedCampaign.name}
                  <span className="text-xs px-2 py-0.5 bg-emerald-950 text-emerald-400 border border-emerald-500/40 rounded-full font-mono">
                    {selectedCampaign.daily_goal} contacts / jour
                  </span>
                </h3>
                <p className="text-xs text-slate-400">{selectedCampaign.objective}</p>
              </div>

              {/* Actions directes */}
              <div className="flex items-center gap-2 flex-wrap">
                <button
                  onClick={() => handlePrepare(selectedCampaign.id)}
                  disabled={isProcessing}
                  className="px-3 py-1.5 bg-indigo-950/80 hover:bg-indigo-900 text-indigo-300 border border-indigo-500/40 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isProcessing ? 'animate-spin' : ''}`} />
                  <span>1. Préparer Quotas</span>
                </button>

                {selectedCampaign.status === 'RUNNING' ? (
                  <button
                    onClick={() => handlePause(selectedCampaign.id)}
                    className="px-3 py-1.5 bg-amber-950/80 hover:bg-amber-900 text-amber-300 border border-amber-500/40 rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                  >
                    <Pause className="w-3.5 h-3.5" />
                    <span>Mettre en pause</span>
                  </button>
                ) : (
                  <button
                    onClick={() => handleLaunch(selectedCampaign.id)}
                    disabled={isProcessing}
                    className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all shadow-md cursor-pointer"
                  >
                    <Play className="w-3.5 h-3.5 fill-current" />
                    <span>2. Lancer vers le Sender</span>
                  </button>
                )}
              </div>
            </div>

            {/* Répartition multi-segments & templates */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center justify-between">
                <span>Répartition par Segments & Templates Associés</span>
                <span className="text-emerald-400 font-mono text-[11px]">
                  Total : {selectedCampaign.segment_allocations.reduce((acc, s) => acc + s.daily_quota, 0)} / {selectedCampaign.daily_goal} contacts
                </span>
              </h4>

              <div className="space-y-2.5">
                {selectedCampaign.segment_allocations.map((alloc, idx) => (
                  <div
                    key={idx}
                    className="p-3.5 bg-slate-950/80 border border-slate-800 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-100">{alloc.segment_name}</span>
                        <span className="text-[10px] bg-indigo-950 text-indigo-300 border border-indigo-500/30 px-2 py-0.5 rounded font-mono">
                          {alloc.segment_id}
                        </span>
                      </div>
                      <div className="text-slate-400 text-[11px] flex items-center gap-1.5">
                        <span>Template :</span>
                        <strong className="text-emerald-300">{alloc.template_name}</strong>
                      </div>
                    </div>

                    <div className="flex items-center gap-4 text-[11px] shrink-0">
                      <div className="text-right">
                        <span className="text-slate-400 block">Quota Quotidien</span>
                        <strong className="text-slate-100 text-sm font-mono">{alloc.daily_quota} / jour</strong>
                      </div>

                      <div className="text-right pl-3 border-l border-slate-800">
                        <span className="text-slate-400 block">Délivrés Réels</span>
                        <strong className="text-emerald-400 text-sm font-mono">{alloc.delivered_count}</strong>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Traçabilité & Exclusions */}
            <div className="p-3 bg-slate-950/40 border border-slate-800/80 rounded-xl text-xs space-y-1.5 text-slate-400">
              <span className="font-bold text-slate-300 uppercase tracking-wider text-[10px] block">
                Règles de conformité & Exclusions automatiques :
              </span>
              <ul className="list-disc list-inside space-y-0.5 text-[11px]">
                <li>Exclusion systématique des contacts ayant demandé un désabonnement (STOP / Opt-out).</li>
                <li>Période de repos anti-harcèlement : aucun contact répété sous {selectedCampaign.exclusions?.exclude_recent_contact_days || 15} jours.</li>
                <li>Résolution préalable des variables et civilités dans WordPress avant transmission au Sender.</li>
              </ul>
            </div>
          </div>
        )}
      </div>

      {/* Modal Création Campagne */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-5 shadow-2xl">
            <h3 className="text-sm font-bold text-slate-100 mb-3 pb-2 border-b border-slate-800">
              Créer une Campagne Multi-Segments
            </h3>

            <form onSubmit={handleCreateCampaign} className="space-y-3 text-xs">
              <div>
                <label className="text-[10px] text-slate-400 block mb-1">Nom de la Campagne *</label>
                <input
                  type="text"
                  required
                  placeholder="ex: Prospection Avocats & Comptables Q3"
                  value={newCampaignName}
                  onChange={(e) => setNewCampaignName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-100"
                />
              </div>

              <div>
                <label className="text-[10px] text-slate-400 block mb-1">Objectif Quotidien Total (ex: 50 contacts/jour)</label>
                <input
                  type="number"
                  required
                  min={1}
                  max={200}
                  value={newDailyGoal}
                  onChange={(e) => setNewDailyGoal(parseInt(e.target.value, 10))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-100 font-mono"
                />
              </div>

              <div>
                <label className="text-[10px] text-slate-400 block mb-1">Description / Stratégie</label>
                <textarea
                  rows={2}
                  placeholder="Objectif de traitement et contexte commercial..."
                  value={newDescription}
                  onChange={(e) => setNewDescription(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-100 resize-none"
                />
              </div>

              <div className="pt-3 border-t border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-3 py-1.5 bg-slate-800 text-slate-300 rounded-lg"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded-lg"
                >
                  Créer la Campagne
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

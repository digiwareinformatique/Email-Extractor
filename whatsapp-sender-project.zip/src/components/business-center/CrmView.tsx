import React, { useState, useEffect } from 'react';
import { 
  Users, Search, Plus, Filter, Download, Phone, Mail, Building, MapPin, 
  Check, X, Eye, ShieldCheck, Tag, Edit3, MessageCircle 
} from 'lucide-react';
import { CrmContact, CivilityType } from '../../types/businessCenter';
import { businessCenterApi } from '../../services/businessCenterApi';

interface CrmViewProps {
  onOpenConversation?: (phone: string) => void;
}

export const CrmView: React.FC<CrmViewProps> = ({ onOpenConversation }) => {
  const [contacts, setContacts] = useState<CrmContact[]>([]);
  const [search, setSearch] = useState('');
  const [segmentFilter, setSegmentFilter] = useState('ALL');
  const [civilityFilter, setCivilityFilter] = useState('ALL');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [selectedContact, setSelectedContact] = useState<CrmContact | null>(null);

  // New Contact Modal
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [formData, setFormData] = useState<{
    phone: string;
    civility: CivilityType;
    first_name: string;
    last_name: string;
    company_name: string;
    profession: string;
    city: string;
    email: string;
    status: CrmContact['status'];
    segment: string;
  }>({
    phone: '',
    civility: 'Non spécifié',
    first_name: '',
    last_name: '',
    company_name: '',
    profession: '',
    city: '',
    email: '',
    status: 'PROSPECT',
    segment: 'ENTREPRISE'
  });

  useEffect(() => {
    loadContacts();
  }, [search, segmentFilter, civilityFilter, statusFilter]);

  const loadContacts = async () => {
    try {
      const list = await businessCenterApi.getCrmContacts({
        search: search || undefined,
        segment: segmentFilter,
        civility: civilityFilter,
        status: statusFilter
      });
      setContacts(list);
    } catch (err) {
      console.error(err);
    }
  };

  const handleSaveContact = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.phone.trim()) return;
    try {
      await businessCenterApi.saveCrmContact({
        phone: formData.phone.trim(),
        civility: formData.civility,
        first_name: formData.first_name.trim() || undefined,
        last_name: formData.last_name.trim() || undefined,
        company_name: formData.company_name.trim() || undefined,
        profession: formData.profession.trim() || undefined,
        city: formData.city.trim() || undefined,
        email: formData.email.trim() || undefined,
        status: formData.status,
        segments: [formData.segment],
        tags: [formData.segment, 'Création Manuelle'],
        notes: [],
        consent_given: true,
        opt_out: false
      });
      setIsModalOpen(false);
      loadContacts();
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="space-y-4">
      {/* Header bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 bg-slate-900/80 p-4 rounded-2xl border border-slate-800">
        <div>
          <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
            <Users className="w-5 h-5 text-emerald-400" />
            CRM Central — Contacts, Civilités & Segments Métier
          </h2>
          <p className="text-xs text-slate-400">
            Base unifiée des destinataires éligibles aux campagnes WhatsApp et aux conversations directes.
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all shadow-md self-start md:self-auto cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Nouveau Contact</span>
        </button>
      </div>

      {/* Filter bar */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 bg-slate-900/50 p-3 rounded-xl border border-slate-800/80 text-xs">
        <div className="relative">
          <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-500" />
          <input
            type="text"
            placeholder="Rechercher nom, entreprise, téléphone..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 placeholder-slate-500 focus:outline-hidden"
          />
        </div>

        <select
          value={civilityFilter}
          onChange={(e) => setCivilityFilter(e.target.value)}
          className="bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-300"
        >
          <option value="ALL">Toutes les civilités</option>
          <option value="Maître">Maître (Avocats, Notaires)</option>
          <option value="Docteur">Docteur (Médecins)</option>
          <option value="Monsieur">Monsieur</option>
          <option value="Madame">Madame</option>
          <option value="Non spécifié">Non spécifié (Neutre)</option>
        </select>

        <select
          value={segmentFilter}
          onChange={(e) => setSegmentFilter(e.target.value)}
          className="bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-300"
        >
          <option value="ALL">Tous les segments</option>
          <option value="AVOCAT">Avocats & Juridique</option>
          <option value="COMPTABLE">Experts-Comptables</option>
          <option value="ENTREPRISE">Sociétés & Entreprises</option>
          <option value="SANTE">Santé & Cliniques</option>
          <option value="ECOLE_PRIVEE">Écoles Privées</option>
        </select>

        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-300"
        >
          <option value="ALL">Tous les statuts</option>
          <option value="PROSPECT">Prospects</option>
          <option value="LEAD">Leads Qualifiés</option>
          <option value="CLIENT">Clients Actifs</option>
          <option value="PARTENAIRE">Partenaires</option>
        </select>
      </div>

      {/* Contacts Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950 text-slate-400 font-semibold border-b border-slate-800 uppercase tracking-wider text-[10px]">
              <tr>
                <th className="py-3 px-4">Contact & Civilité</th>
                <th className="py-3 px-4">Téléphone WhatsApp</th>
                <th className="py-3 px-4">Entreprise & Profession</th>
                <th className="py-3 px-4">Segments & Tags</th>
                <th className="py-3 px-4">Statut Commercial</th>
                <th className="py-3 px-4">Commandes WC</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {contacts.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-500">
                    Aucun contact trouvé pour ces critères.
                  </td>
                </tr>
              ) : (
                contacts.map(c => (
                  <tr key={c.id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-3 px-4">
                      <div className="font-bold text-slate-100 flex items-center gap-1.5">
                        {c.civility !== 'Non spécifié' && (
                          <span className="text-emerald-400 font-normal">{c.civility}</span>
                        )}
                        <span>{c.first_name || ''} {c.last_name || ''}</span>
                        {!c.first_name && !c.last_name && (
                          <span className="text-slate-400 italic">Non renseigné</span>
                        )}
                      </div>
                      {c.city && <span className="text-[10px] text-slate-500 block">{c.city}</span>}
                    </td>

                    <td className="py-3 px-4 font-mono text-emerald-400 font-semibold">
                      {c.phone}
                    </td>

                    <td className="py-3 px-4">
                      <div className="font-medium text-slate-200">{c.company_name || '—'}</div>
                      <div className="text-[10px] text-slate-400">{c.profession || ''}</div>
                    </td>

                    <td className="py-3 px-4">
                      <div className="flex flex-wrap gap-1">
                        {c.segments.map((seg, idx) => (
                          <span key={idx} className="bg-indigo-950 text-indigo-300 border border-indigo-500/30 text-[9px] px-1.5 py-0.5 rounded font-semibold">
                            {seg}
                          </span>
                        ))}
                        {c.tags.slice(0, 2).map((t, idx) => (
                          <span key={idx} className="bg-slate-800 text-slate-400 text-[9px] px-1.5 py-0.5 rounded">
                            {t}
                          </span>
                        ))}
                      </div>
                    </td>

                    <td className="py-3 px-4">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        c.status === 'CLIENT' ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/30' :
                        c.status === 'LEAD' ? 'bg-blue-950 text-blue-300 border border-blue-500/30' :
                        c.status === 'DÉSINSCRIT' ? 'bg-rose-950 text-rose-300' :
                        'bg-slate-800 text-slate-300'
                      }`}>
                        {c.status}
                      </span>
                    </td>

                    <td className="py-3 px-4">
                      {c.woocommerce_orders.length > 0 ? (
                        <span className="text-emerald-400 font-semibold">
                          {c.woocommerce_orders.length} cmd ({c.woocommerce_orders[0].total})
                        </span>
                      ) : (
                        <span className="text-slate-500">—</span>
                      )}
                    </td>

                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={() => onOpenConversation && onOpenConversation(c.phone)}
                        className="px-2.5 py-1 bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/40 rounded-lg text-xs font-semibold inline-flex items-center gap-1 transition-all cursor-pointer"
                        title="Ouvrir la conversation dans l'interface Conversations"
                      >
                        <MessageCircle className="w-3.5 h-3.5" />
                        <span>Discuter</span>
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Nouveau Contact */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-5 shadow-2xl animate-in fade-in">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
              <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                <Plus className="w-4 h-4 text-emerald-400" />
                Ajouter un contact au CRM
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveContact} className="space-y-3 text-xs">
              <div>
                <label className="text-[10px] text-slate-400 block mb-1">Téléphone WhatsApp (E.164 ou local) *</label>
                <input
                  type="text"
                  placeholder="+216 98 123 456"
                  required
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-slate-100 focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] text-slate-400 block mb-1">Civilité / Titre respectueux</label>
                  <select
                    value={formData.civility}
                    onChange={(e) => setFormData({ ...formData, civility: e.target.value as any })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2 py-1.5 text-slate-200"
                  >
                    <option value="Non spécifié">Non spécifié (Neutre)</option>
                    <option value="Monsieur">Monsieur</option>
                    <option value="Madame">Madame</option>
                    <option value="Maître">Maître (Avocat, Notaire)</option>
                    <option value="Docteur">Docteur (Santé)</option>
                  </select>
                </div>

                <div>
                  <label className="text-[10px] text-slate-400 block mb-1">Statut Commercial</label>
                  <select
                    value={formData.status}
                    onChange={(e) => setFormData({ ...formData, status: e.target.value as any })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2 py-1.5 text-slate-200"
                  >
                    <option value="PROSPECT">Prospect</option>
                    <option value="LEAD">Lead Qualifié</option>
                    <option value="CLIENT">Client</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] text-slate-400 block mb-1">Prénom</label>
                  <input
                    type="text"
                    value={formData.first_name}
                    onChange={(e) => setFormData({ ...formData, first_name: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-slate-100"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-slate-400 block mb-1">Nom</label>
                  <input
                    type="text"
                    value={formData.last_name}
                    onChange={(e) => setFormData({ ...formData, last_name: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-slate-100"
                  />
                </div>
              </div>

              <div>
                <label className="text-[10px] text-slate-400 block mb-1">Entreprise ou Cabinet</label>
                <input
                  type="text"
                  placeholder="ex: Cabinet d'Avocats Ben Amor"
                  value={formData.company_name}
                  onChange={(e) => setFormData({ ...formData, company_name: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-slate-100"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] text-slate-400 block mb-1">Profession</label>
                  <input
                    type="text"
                    placeholder="ex: Avocat"
                    value={formData.profession}
                    onChange={(e) => setFormData({ ...formData, profession: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-slate-100"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-slate-400 block mb-1">Ville</label>
                  <input
                    type="text"
                    placeholder="Tunis, Sousse..."
                    value={formData.city}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-slate-100"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-3 py-1.5 bg-slate-800 text-slate-300 rounded-lg"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded-lg shadow-sm"
                >
                  Enregistrer
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import { 
  X, Download, FileSpreadsheet, Mail, Phone, 
  Layers, Check, Sparkles, Filter 
} from 'lucide-react';
import { LeadExportOptions, SegmentDefinition, LeadFilterOptions } from '../../types/lead';
import { leadApi } from '../../services/leadApi';

interface ExportModalProps {
  isOpen?: boolean;
  segments: SegmentDefinition[];
  filterOptions?: LeadFilterOptions;
  onClose: () => void;
}

export const ExportModal: React.FC<ExportModalProps> = ({ 
  isOpen = true, 
  segments, 
  filterOptions,
  onClose 
}) => {
  const [exportType, setExportType] = useState<LeadExportOptions['type']>('complete');
  const [selectedSegment, setSelectedSegment] = useState<string>(segments[0]?.code || 'AVOCAT');
  const [isExporting, setIsExporting] = useState<boolean>(false);

  // Close on Escape key
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && !isExporting) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, isExporting, onClose]);

  if (!isOpen) return null;

  const handleExport = async () => {
    setIsExporting(true);
    try {
      await leadApi.exportCSV({
        type: exportType,
        segmentCode: exportType === 'by_segment' ? selectedSegment : undefined
      });
      setIsExporting(false);
      onClose();
    } catch (err) {
      console.error('Export failed:', err);
      setIsExporting(false);
    }
  };

  return (
    <div 
      className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200"
      onClick={(e) => {
        if (e.target === e.currentTarget && !isExporting) {
          onClose();
        }
      }}
    >
      <div 
        className="bg-white rounded-2xl max-w-lg w-full border border-slate-200 shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-6 py-4.5 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-400/30 flex items-center justify-center text-emerald-400">
              <Download className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Exporter les Leads Enrichis</h2>
              <p className="text-xs text-slate-300">Format CSV compatible Excel & plateformes marketing (UTF-8 BOM)</p>
            </div>
          </div>
          <button 
            type="button"
            onClick={onClose} 
            disabled={isExporting}
            className="text-slate-400 hover:text-white p-1 rounded-lg transition-colors cursor-pointer disabled:opacity-40"
            aria-label="Fermer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4">
          <label className="text-xs font-bold text-slate-700 block">Sélectionnez le format d'export :</label>

          <div className="grid grid-cols-1 gap-2.5">
            {/* Option 1: Export Complet */}
            <button
              type="button"
              onClick={() => setExportType('complete')}
              className={`p-3.5 rounded-xl border text-left flex items-start gap-3 transition-all cursor-pointer ${
                exportType === 'complete'
                  ? 'border-indigo-600 bg-indigo-50/50 ring-2 ring-indigo-600/20'
                  : 'border-slate-200 hover:border-slate-300 bg-white'
              }`}
            >
              <div className="p-2 bg-indigo-100 text-indigo-700 rounded-lg mt-0.5">
                <FileSpreadsheet className="w-4 h-4" />
              </div>
              <div className="flex-1">
                <div className="text-xs font-bold text-slate-900">Export Complet BDD (Toutes les colonnes)</div>
                <div className="text-[11px] text-slate-500 mt-0.5">
                  ID, Téléphones, Nom, Société, Profession, Secteur, Ville, Email, Site, Confiance & Statut.
                </div>
              </div>
            </button>

            {/* Option 2: Export Email Only */}
            <button
              type="button"
              onClick={() => setExportType('email_only')}
              className={`p-3.5 rounded-xl border text-left flex items-start gap-3 transition-all cursor-pointer ${
                exportType === 'email_only'
                  ? 'border-emerald-600 bg-emerald-50/50 ring-2 ring-emerald-600/20'
                  : 'border-slate-200 hover:border-slate-300 bg-white'
              }`}
            >
              <div className="p-2 bg-emerald-100 text-emerald-700 rounded-lg mt-0.5">
                <Mail className="w-4 h-4" />
              </div>
              <div className="flex-1">
                <div className="text-xs font-bold text-slate-900">Export Email Marketing (Leads avec Email Pro)</div>
                <div className="text-[11px] text-slate-500 mt-0.5">
                  Idéal pour CRM, Mailchimp, Brevo. Filtre automatique des contacts ayant un email public valide.
                </div>
              </div>
            </button>

            {/* Option 3: Export Phone Only */}
            <button
              type="button"
              onClick={() => setExportType('phone_only')}
              className={`p-3.5 rounded-xl border text-left flex items-start gap-3 transition-all cursor-pointer ${
                exportType === 'phone_only'
                  ? 'border-blue-600 bg-blue-50/50 ring-2 ring-blue-600/20'
                  : 'border-slate-200 hover:border-slate-300 bg-white'
              }`}
            >
              <div className="p-2 bg-blue-100 text-blue-700 rounded-lg mt-0.5">
                <Phone className="w-4 h-4" />
              </div>
              <div className="flex-1">
                <div className="text-xs font-bold text-slate-900">Export Téléphone Direct & SMS</div>
                <div className="text-[11px] text-slate-500 mt-0.5">
                  Nom, Société, Téléphone National, E.164, Opérateur, Secteur et Ville.
                </div>
              </div>
            </button>

            {/* Option 4: Export par Segment */}
            <button
              type="button"
              onClick={() => setExportType('by_segment')}
              className={`p-3.5 rounded-xl border text-left flex items-start gap-3 transition-all cursor-pointer ${
                exportType === 'by_segment'
                  ? 'border-purple-600 bg-purple-50/50 ring-2 ring-purple-600/20'
                  : 'border-slate-200 hover:border-slate-300 bg-white'
              }`}
            >
              <div className="p-2 bg-purple-100 text-purple-700 rounded-lg mt-0.5">
                <Layers className="w-4 h-4" />
              </div>
              <div className="flex-1">
                <div className="text-xs font-bold text-slate-900">Export Ciblé par Secteur / Segment</div>
                <div className="text-[11px] text-slate-500 mt-0.5">
                  Génère un fichier filtré uniquement pour un secteur donné (ex: Avocats, Écoles, etc.).
                </div>
              </div>
            </button>
          </div>

          {/* Segment Selector if by_segment is chosen */}
          {exportType === 'by_segment' && (
            <div className="pt-2">
              <label className="text-xs font-bold text-slate-700 block mb-1">Choisir le secteur à exporter :</label>
              <select
                value={selectedSegment}
                onChange={(e) => setSelectedSegment(e.target.value)}
                className="w-full px-3 py-2 text-xs font-semibold bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500/20 focus:border-purple-500"
              >
                {segments.map((s) => (
                  <option key={s.id} value={s.code}>
                    {s.label} ({s.code})
                  </option>
                ))}
              </select>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex items-center justify-end gap-2.5">
          <button
            type="button"
            onClick={onClose}
            disabled={isExporting}
            className="px-4 py-2 text-xs font-bold text-slate-600 hover:text-slate-800 rounded-xl transition-colors cursor-pointer disabled:opacity-40"
          >
            Annuler
          </button>
          <button
            type="button"
            onClick={handleExport}
            disabled={isExporting}
            className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl transition-all shadow-xs flex items-center gap-2 cursor-pointer disabled:opacity-50"
          >
            <Download className="w-4 h-4" />
            <span>{isExporting ? 'Génération du CSV...' : 'Télécharger le Fichier CSV'}</span>
          </button>
        </div>

      </div>
    </div>
  );
};

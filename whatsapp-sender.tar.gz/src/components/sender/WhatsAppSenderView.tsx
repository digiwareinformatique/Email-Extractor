/**
 * WhatsApp Sender - V2 Moteur d'Exécution Automatisé & Bouclier Anti-Ban
 * Pure Background Execution Engine with Spintax, Anti-Ban Throttling, Blacklist & Kill-Switch
 */
import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  Send,
  Radio,
  Play,
  Pause,
  RotateCcw,
  Trash2,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Clock,
  ShieldCheck,
  Zap,
  Activity,
  Phone,
  RefreshCw,
  QrCode,
  Smartphone,
  ExternalLink,
  ShieldAlert,
  Sparkles,
  UserX,
  Plus,
  Flame,
  Layers,
  FileText,
  Key,
  Copy,
  Check,
  ListFilter,
  ChevronDown,
  ChevronRight
} from 'lucide-react';
import {
  SenderJob,
  SenderSession,
  SenderSettings,
  SenderMetrics,
  SenderLog,
  SenderJobStatus,
  BlacklistEntry
} from '../../types/sender';
import { senderApi } from '../../services/senderApi';
import QRCode from 'qrcode';

type ActiveTab = 'QUEUE' | 'SPINTAX_TESTER' | 'BLACKLIST' | 'SESSION' | 'SETTINGS' | 'LOGS';

export const WhatsAppSenderView: React.FC = () => {
  // Navigation & View state
  const [activeTab, setActiveTab] = useState<ActiveTab>('QUEUE');
  const [session, setSession] = useState<SenderSession | null>(null);
  const [metrics, setMetrics] = useState<SenderMetrics | null>(null);
  const [settings, setSettings] = useState<SenderSettings | null>(null);
  const [jobs, setJobs] = useState<SenderJob[]>([]);
  const [totalJobs, setTotalJobs] = useState(0);
  const [logs, setLogs] = useState<SenderLog[]>([]);
  const [blacklist, setBlacklist] = useState<BlacklistEntry[]>([]);
  const [statusFilter, setStatusFilter] = useState<SenderJobStatus | 'ALL'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [notification, setNotification] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null);

  // Spintax Tester State
  const [spintaxInput, setSpintaxInput] = useState('{Bonjour|Salut|Enchanté} {Docteur|Chère équipe}, {j\'ai vu votre activité|je vous contacte suite à votre fiche} {sur Google|sur l\'annuaire}.');
  const [spintaxVariations, setSpintaxVariations] = useState<string[]>([]);
  const [isSpintaxLoading, setIsSpintaxLoading] = useState(false);

  // Blacklist form & simulation state
  const [newBlacklistPhone, setNewBlacklistPhone] = useState('');
  const [newBlacklistReason, setNewBlacklistReason] = useState('MANUAL_ADD');
  const [simPhone, setSimPhone] = useState('+216 98 000 111');
  const [simMessage, setSimMessage] = useState('STOP');
  const [simResult, setSimResult] = useState<string | null>(null);

  // Session connection inputs
  const [directPhone, setDirectPhone] = useState('+216 98 123 456');
  const [directPushName, setDirectPushName] = useState('Session WhatsApp Pro');
  const [sessionMethod, setSessionMethod] = useState<'QR' | 'PAIRING_CODE' | 'DIRECT'>('QR');
  const [pairingPhone, setPairingPhone] = useState('+216 98 123 456');
  const [pairingCodeResult, setPairingCodeResult] = useState<string | null>(null);
  const [isRequestingPairingCode, setIsRequestingPairingCode] = useState(false);

  // Selected Job modal
  const [selectedJob, setSelectedJob] = useState<SenderJob | null>(null);
  const [selectedJobLogs, setSelectedJobLogs] = useState<SenderLog[]>([]);

  // Settings form state
  const [settingsForm, setSettingsForm] = useState<Partial<SenderSettings>>({});

  // Quick Send & Demo State
  const [isQuickSendOpen, setIsQuickSendOpen] = useState(false);
  const [quickPhone, setQuickPhone] = useState('+216 98 456 789');
  const [quickName, setQuickName] = useState('Cabinet d\'Avocats');
  const [quickCampaign, setQuickCampaign] = useState('CAMP_AUDIT_KMS');
  const [quickMessage, setQuickMessage] = useState('{Bonjour|Salut|Enchanté} {nom},\n\n{Saviez-vous que 80% des cracks Windows et Office KMS exposent les cabinets à des fuites de données confidentielles ?|DigiWare vous accompagne dans la sécurisation de votre parc informatique.}\n\nTestez vos postes en 5 secondes avec la commande CMD : slmgr /dli\n\nLicences 100% officielles (Windows 11 Pro, Office 2024, Kaspersky) avec facture légale et matricule fiscal tunisien.\n\nCordialement,\nL\'équipe DigiWare Tunisie');

  // Direct Unit Test Real Send State
  const [testPhone, setTestPhone] = useState('+216 98 123 456');
  const [testMessage, setTestMessage] = useState('Test réel WhatsApp Sender.');
  const [isTestingSend, setIsTestingSend] = useState(false);
  const [testResult, setTestResult] = useState<{
    success: boolean;
    job?: SenderJob;
    logs?: SenderLog[];
    message?: string;
  } | null>(null);

  // Real-time Logs & Copy Management
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [logFilterJobId, setLogFilterJobId] = useState<string>('ALL'); // 'ALL' | 'LAST' | jobId
  const [expandedLogId, setExpandedLogId] = useState<string | null>(null);

  const qrCanvasRef = useRef<HTMLCanvasElement | null>(null);

  const notify = (text: string, type: 'success' | 'error' | 'info' = 'info') => {
    setNotification({ type, text });
    setTimeout(() => setNotification(null), 5000);
  };

  const copyTextToClipboard = async (text: string, key: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedKey(key);
      notify('Journal copié dans le presse-papiers avec succès !', 'success');
      setTimeout(() => setCopiedKey(null), 3000);
    } catch {
      notify('Impossible de copier dans le presse-papiers', 'error');
    }
  };

  const formatLogsForClipboard = (
    title: string,
    jobInfo: Partial<SenderJob> | null,
    logsList: SenderLog[]
  ): string => {
    const timestamp = new Date().toLocaleString();
    let text = `==================================================\n`;
    text += `${title.toUpperCase()}\n`;
    text += `Date de l'export : ${timestamp}\n`;
    if (jobInfo) {
      text += `Destinataire : +${jobInfo.phone || '—'}\n`;
      text += `Job ID : ${jobInfo.id || '—'}\n`;
      text += `Stanza Message ID : ${jobInfo.external_message_id || '—'}\n`;
      text += `Statut Final : ${jobInfo.status || '—'} (Accusé livraison: ${jobInfo.delivery_ack || '—'})\n`;
      if (jobInfo.error_code) {
        text += `Erreur : [${jobInfo.error_code}] ${jobInfo.error_message || ''}\n`;
      }
      if (jobInfo.message) {
        text += `Message : "${jobInfo.message}"\n`;
      }
    }
    text += `==================================================\n\n`;
    text += `--- ÉVÉNEMENTS CHRONOLOGIQUES (${logsList.length} logs) ---\n`;

    const sorted = [...logsList].sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());
    for (const l of sorted) {
      const time = new Date(l.created_at).toLocaleTimeString();
      text += `[${time}] [${l.event}] (${l.level}) : ${l.message}\n`;
      if (l.details && Object.keys(l.details).length > 0) {
        text += `       Détails : ${JSON.stringify(l.details)}\n`;
      }
    }
    return text;
  };

  const handleCopyLastSendLogs = () => {
    if (testResult && testResult.logs && testResult.logs.length > 0) {
      const formatted = formatLogsForClipboard('Rapport du Dernier Envoi (Test Unitaire)', testResult.job || null, testResult.logs);
      copyTextToClipboard(formatted, 'last-send-test');
      return;
    }

    if (jobs.length > 0) {
      const latestJob = jobs[0];
      senderApi.getLogs(50, latestJob.id).then(res => {
        const formatted = formatLogsForClipboard(`Rapport du Dernier Envoi (Job ${latestJob.id})`, latestJob, res);
        copyTextToClipboard(formatted, 'last-send-test');
      }).catch(() => {
        notify('Impossible de récupérer les logs du dernier envoi', 'error');
      });
      return;
    }

    notify('Aucun envoi récent disponible pour la copie', 'info');
  };

  const handleCopySpecificJobLogs = async (job: SenderJob) => {
    try {
      const jobLogs = await senderApi.getLogs(50, job.id);
      const formatted = formatLogsForClipboard(`Rapport d'Envoi - Prospect +${job.phone} (Job ${job.id})`, job, jobLogs);
      copyTextToClipboard(formatted, `job-${job.id}`);
    } catch {
      notify(`Erreur lors de la récupération des logs du job ${job.id}`, 'error');
    }
  };

  // Poll Core Engine Data
  const fetchEngineData = useCallback(async () => {
    try {
      const statusRes = await senderApi.getStatus();
      setSession(statusRes.session);
      setMetrics(statusRes.metrics);
      setSettings(statusRes.settings);
      setSettingsForm(statusRes.settings);

      const jobsRes = await senderApi.getJobs({
        status: statusFilter,
        search: searchQuery,
        limit: 50
      });
      setJobs(jobsRes.jobs);
      setTotalJobs(jobsRes.total);
    } catch (err: any) {
      if (err.message !== 'SERVEUR_EN_COURS_DE_DEMARRAGE') {
        console.warn('[WhatsApp Sender] Polling warning:', err.message);
      }
    } finally {
      setIsLoading(false);
    }
  }, [statusFilter, searchQuery]);

  useEffect(() => {
    fetchEngineData();
    const interval = setInterval(fetchEngineData, 3000);
    return () => clearInterval(interval);
  }, [fetchEngineData]);

  // Load Logs or Blacklist when tabs switch
  useEffect(() => {
    if (activeTab === 'LOGS') {
      senderApi.getLogs(80).then(setLogs).catch(() => {});
    } else if (activeTab === 'BLACKLIST') {
      senderApi.getBlacklist().then(setBlacklist).catch(() => {});
    }
  }, [activeTab]);

  // Canvas Fallback for QR Code
  useEffect(() => {
    if (session?.status === 'AUTH_REQUIRED' && qrCanvasRef.current) {
      const canvas = qrCanvasRef.current;
      const payload = session.qrCode || `2@WHATSAPP_STEALTH_PAYLOAD_${Date.now()}`;
      QRCode.toCanvas(canvas, payload, {
        width: 240,
        margin: 2,
        color: { dark: '#0f172a', light: '#ffffff' }
      }).catch(() => {});
    }
  }, [session?.status, session?.qrCode]);

  // ---------------------------------------------------------------------------
  // Action Handlers
  // ---------------------------------------------------------------------------

  const handleEmergencyStop = async () => {
    try {
      setActionLoading('emergency');
      await senderApi.triggerEmergencyStop();
      notify('🚨 ARRÊT D\'URGENCE DÉCLENCHÉ : Exécutions interrompues et file d\'attente gelée !', 'error');
      await fetchEngineData();
    } catch (err: any) {
      notify(err.message, 'error');
    } finally {
      setActionLoading(null);
    }
  };

  const handleEmergencyResume = async () => {
    try {
      setActionLoading('resume');
      await senderApi.resumeFromEmergencyStop();
      notify('Reprise autorisée : File d\'attente et worker réactivés.', 'success');
      await fetchEngineData();
    } catch (err: any) {
      notify(err.message, 'error');
    } finally {
      setActionLoading(null);
    }
  };

  const handleToggleQueuePause = async () => {
    if (!metrics) return;
    try {
      setActionLoading('queue-toggle');
      if (metrics.isQueuePaused) {
        await senderApi.resumeQueue();
        notify('File d\'attente reprise. Les envois automatisés continuent.', 'success');
      } else {
        await senderApi.pauseQueue();
        notify('File d\'attente mise en pause.', 'info');
      }
      await fetchEngineData();
    } catch (err: any) {
      notify(err.message, 'error');
    } finally {
      setActionLoading(null);
    }
  };

  const handleRetryAll = async () => {
    try {
      setActionLoading('retry-all');
      const count = await senderApi.retryAllFailed();
      notify(`${count} jobs en échec ont été remis en file d'attente.`, 'success');
      await fetchEngineData();
    } catch (err: any) {
      notify(err.message, 'error');
    } finally {
      setActionLoading(null);
    }
  };

  const handleClearFinished = async () => {
    try {
      setActionLoading('clear-finished');
      const count = await senderApi.clearFinished();
      notify(`${count} jobs terminés ont été purgés de la file.`, 'info');
      await fetchEngineData();
    } catch (err: any) {
      notify(err.message, 'error');
    } finally {
      setActionLoading(null);
    }
  };

  const handleConnectSession = async () => {
    try {
      setActionLoading('connect');
      const updated = await senderApi.connectSession();
      setSession(updated);
      notify('Session initialisée en mode Stealth. Prête pour l\'appairage.', 'info');
    } catch (err: any) {
      notify(err.message, 'error');
    } finally {
      setActionLoading(null);
    }
  };

  const handleConfirmSession = async () => {
    try {
      setActionLoading('confirm-session');
      const updated = await senderApi.confirmSession(directPhone, directPushName);
      setSession(updated);
      notify(`Session WhatsApp Web activée et persistée pour ${directPhone}.`, 'success');
      await fetchEngineData();
    } catch (err: any) {
      notify(err.message, 'error');
    } finally {
      setActionLoading(null);
    }
  };

  const handleRequestPairingCode = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!pairingPhone.trim()) return;
    try {
      setIsRequestingPairingCode(true);
      const res = await senderApi.requestPairingCode(pairingPhone);
      setPairingCodeResult(res.pairingCode);
      notify(`Code d'association généré : ${res.pairingCode}`, 'success');
      await fetchEngineData();
    } catch (err: any) {
      notify(err.message || 'Erreur lors de la génération du code', 'error');
    } finally {
      setIsRequestingPairingCode(false);
    }
  };

  const handleExecuteRealTestSend = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!testPhone.trim() || !testMessage.trim()) return;
    try {
      setIsTestingSend(true);
      setTestResult(null);
      const res = await senderApi.testSend(testPhone, testMessage);
      setTestResult(res);
      if (res.success) {
        notify('✓ MESSAGE ENVOYÉ avec succès dans WhatsApp Web !', 'success');
      } else {
        notify(`✕ Échec de l'envoi : ${res.job?.error_message || res.message || 'Erreur inconnue'}`, 'error');
      }
      await fetchEngineData();
    } catch (err: any) {
      setTestResult({
        success: false,
        message: err.message || 'Erreur lors du déclenchement du test d\'envoi'
      });
      notify(err.message, 'error');
    } finally {
      setIsTestingSend(false);
    }
  };

  const handleQuickSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickPhone.trim() || !quickMessage.trim()) return;
    try {
      setActionLoading('quick-send');
      await senderApi.createJob({
        phone: quickPhone,
        message: quickMessage,
        campaign_id: quickCampaign.trim() || 'CAMP_DIRECT_TEST',
        metadata: {
          nom: quickName.trim() || 'Monsieur/Madame',
          name: quickName.trim() || 'Monsieur/Madame',
          source: 'Quick Send Direct'
        }
      });
      notify(`Message pour ${quickPhone} injecté dans la file d'attente automatisée !`, 'success');
      setIsQuickSendOpen(false);
      await fetchEngineData();
    } catch (err: any) {
      notify(err.message, 'error');
    } finally {
      setActionLoading(null);
    }
  };

  const handleInjectDemoContacts = async () => {
    try {
      setActionLoading('demo-inject');
      const demoJobs = [
        {
          phone: '+216 98 111 222',
          message: '{Bonjour|Salut|Enchanté} Maître {nom},\n\n{Pour tester la conformité de vos postes informatiques|Dans le cadre de l\'audit de sécurité de votre cabinet}, tapez dans l\'invite de commande CMD :\n👉 slmgr /dli\n\nDigiWare vous fournit les clés 100% officielles Microsoft Office 2024 Pro Plus et Windows 11 avec facture légale tunisienne.\n\nCordialement,\nDigiWare Informatique',
          campaign_id: 'CAMP_AUDIT_KMS',
          metadata: { nom: 'Ben Salem', company: 'Cabinet d\'Avocats Ben Salem', city: 'Tunis' }
        },
        {
          phone: '+216 98 333 444',
          message: '{Bonjour|Bonjour l\'équipe} {nom},\n\nDigiWare distribue les clés logicielles certifiées pour entreprises :\n• Windows 11 Pro Retail\n• Office 2024 Pro Plus\n• Kaspersky Total Security\n\nFacture légale avec matricule fiscal déductible.\n\nSouhaitez-vous notre grille tarifaire entreprise ?\n\nBien à vous,\nDigiWare',
          campaign_id: 'CAMP_OFFICIEL_B2B',
          metadata: { nom: 'Cabinet Expert Comptable', company: 'Expertise Comptable', city: 'Sfax' }
        },
        {
          phone: '+216 98 555 666',
          message: '{Bonjour|Salut confrère} {nom},\n\nVous réalisez de la maintenance ou de la vente de matériel informatique ? DigiWare vous propose des packs de clés logicielles à tarifs grossistes pour revendeurs.\n\nL\'équipe DigiWare',
          campaign_id: 'CAMP_REVENDEURS',
          metadata: { nom: 'Atelier IT', company: 'Informatique Pro', city: 'Sousse' }
        }
      ];
      await senderApi.createBulkJobs(demoJobs, 'CAMP_DEMO_DIGIWARE', 'TPL_DEMO');
      notify('3 prospects B2B de test DigiWare injectés dans la file d\'attente automatisée !', 'success');
      await fetchEngineData();
    } catch (err: any) {
      notify(err.message, 'error');
    } finally {
      setActionLoading(null);
    }
  };

  const handleDisconnect = async () => {
    try {
      setActionLoading('disconnect');
      const updated = await senderApi.disconnectSession();
      setSession(updated);
      notify('Session WhatsApp Web déconnectée et données locales purgées.', 'info');
      await fetchEngineData();
    } catch (err: any) {
      notify(err.message, 'error');
    } finally {
      setActionLoading(null);
    }
  };

  const handleCancelSingleJob = async (id: string) => {
    try {
      await senderApi.cancelJob(id);
      notify(`Job ${id} annulé.`, 'info');
      await fetchEngineData();
    } catch (err: any) {
      notify(err.message, 'error');
    }
  };

  const handleRetrySingleJob = async (id: string) => {
    try {
      await senderApi.retryJob(id);
      notify(`Job ${id} replacé en file d'attente.`, 'success');
      await fetchEngineData();
    } catch (err: any) {
      notify(err.message, 'error');
    }
  };

  const handleOpenJobDetails = async (job: SenderJob) => {
    setSelectedJob(job);
    try {
      const res = await senderApi.getJobById(job.id);
      setSelectedJobLogs(res.logs || []);
    } catch {
      setSelectedJobLogs([]);
    }
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setActionLoading('save-settings');
      const updated = await senderApi.updateSettings(settingsForm);
      setSettings(updated);
      notify('Paramètres Anti-Ban et Warm-up mis à jour avec succès.', 'success');
    } catch (err: any) {
      notify(err.message, 'error');
    } finally {
      setActionLoading(null);
    }
  };

  const handleGenerateSpintax = async () => {
    if (!spintaxInput.trim()) return;
    try {
      setIsSpintaxLoading(true);
      const res = await senderApi.previewSpintax(spintaxInput, 5);
      setSpintaxVariations(res.variations || []);
      notify('5 variations uniques générées avec succès !', 'success');
    } catch (err: any) {
      notify(err.message, 'error');
    } finally {
      setIsSpintaxLoading(false);
    }
  };

  const handleAddToBlacklist = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newBlacklistPhone.trim()) return;
    try {
      setActionLoading('add-bl');
      const entry = await senderApi.addToBlacklist(newBlacklistPhone, newBlacklistReason);
      setBlacklist([entry, ...blacklist]);
      setNewBlacklistPhone('');
      notify(`Numéro ${entry.phone} ajouté à la Blacklist. Tâches associées annulées.`, 'success');
      await fetchEngineData();
    } catch (err: any) {
      notify(err.message, 'error');
    } finally {
      setActionLoading(null);
    }
  };

  const handleRemoveFromBlacklist = async (phone: string) => {
    try {
      await senderApi.removeFromBlacklist(phone);
      setBlacklist(blacklist.filter(b => b.phone !== phone));
      notify(`Numéro ${phone} retiré de la Blacklist.`, 'info');
      await fetchEngineData();
    } catch (err: any) {
      notify(err.message, 'error');
    }
  };

  const handleSimulateReply = async () => {
    if (!simPhone.trim() || !simMessage.trim()) return;
    try {
      const res = await senderApi.simulateReply(simPhone, simMessage);
      if (res.isOptOut) {
        setSimResult(`🚨 OPT-OUT DÉTECTÉ ! Le numéro ${simPhone} a été immédiatement ajouté à la Blacklist et toutes ses tâches en attente ont été annulées.`);
      } else {
        setSimResult(`ℹ️ Message classique reçu de ${simPhone}. Aucun mot-clé d'arrêt détecté.`);
      }
      senderApi.getBlacklist().then(setBlacklist).catch(() => {});
      await fetchEngineData();
    } catch (err: any) {
      notify(err.message, 'error');
    }
  };

  return (
    <div className="flex-1 flex flex-col min-h-screen bg-slate-950 text-slate-100 font-sans">
      {/* ------------------------------------------------------------- */}
      {/* Top Header: Execution Status & Emergency Kill Switch          */}
      {/* ------------------------------------------------------------- */}
      <header className="border-b border-slate-800 bg-slate-900/90 backdrop-blur-md px-6 py-4 sticky top-0 z-30 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shadow-inner">
            <Send className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h1 className="text-lg font-bold text-white tracking-tight">WhatsApp Sender</h1>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 uppercase tracking-wider">
                Moteur Automatisé V2
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Exécution autonome en arrière-plan • Bouclier Anti-Ban • Spintax & Blacklist
            </p>
          </div>
        </div>

        {/* Action Controls & Emergency Stop */}
        <div className="flex items-center flex-wrap gap-2.5">
          {/* Session Indicator */}
          <button
            onClick={() => setActiveTab('SESSION')}
            className={`flex items-center space-x-2 px-3 py-1.5 rounded-lg border text-xs transition-all ${
              session?.status === 'CONNECTED'
                ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300 hover:bg-emerald-900/30'
                : 'bg-amber-950/40 border-amber-500/40 text-amber-300 hover:bg-amber-900/30 cursor-pointer'
            }`}
            title="Gérer la session WhatsApp Web"
          >
            <div className={`w-2.5 h-2.5 rounded-full ${session?.status === 'CONNECTED' ? 'bg-emerald-400 animate-pulse shadow-[0_0_8px_rgba(52,211,153,0.8)]' : 'bg-amber-400 animate-ping'}`} />
            <span className="font-semibold">
              {session?.status === 'CONNECTED' ? (session.phoneNumber || 'WhatsApp Web Connecté') : 'Non Connecté • Scanner QR'}
            </span>
          </button>

          {/* Pause / Resume Queue */}
          <button
            onClick={handleToggleQueuePause}
            disabled={actionLoading === 'queue-toggle' || metrics?.emergencyStopped}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition-all border ${
              metrics?.isQueuePaused
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 hover:bg-amber-500/30'
                : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700/80'
            }`}
          >
            {metrics?.isQueuePaused ? <Play className="w-3.5 h-3.5 fill-current" /> : <Pause className="w-3.5 h-3.5 fill-current" />}
            <span>{metrics?.isQueuePaused ? 'Reprendre la File' : 'Mettre en Pause'}</span>
          </button>

          {/* Emergency Kill Switch */}
          {metrics?.emergencyStopped ? (
            <button
              onClick={handleEmergencyResume}
              disabled={actionLoading === 'resume'}
              className="px-3.5 py-1.5 rounded-lg text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white flex items-center space-x-1.5 shadow-lg shadow-emerald-950/50 transition-all border border-emerald-400"
            >
              <Zap className="w-3.5 h-3.5" />
              <span>DÉBLOQUER L'ARRÊT D'URGENCE</span>
            </button>
          ) : (
            <button
              onClick={handleEmergencyStop}
              disabled={actionLoading === 'emergency'}
              className="px-3.5 py-1.5 rounded-lg text-xs font-bold bg-rose-600/90 hover:bg-rose-500 text-white flex items-center space-x-1.5 shadow-lg shadow-rose-950/50 transition-all border border-rose-400 animate-pulse"
              title="Arrêt d'urgence immédiat de tous les envois"
            >
              <ShieldAlert className="w-3.5 h-3.5" />
              <span>🚨 ARRÊT D'URGENCE</span>
            </button>
          )}
        </div>
      </header>

      {/* Notification Toast */}
      {notification && (
        <div className={`mx-6 mt-4 p-3.5 rounded-xl border flex items-center justify-between text-xs font-medium transition-all ${
          notification.type === 'error'
            ? 'bg-rose-950/70 border-rose-800/80 text-rose-200'
            : notification.type === 'success'
            ? 'bg-emerald-950/70 border-emerald-800/80 text-emerald-200'
            : 'bg-blue-950/70 border-blue-800/80 text-blue-200'
        }`}>
          <div className="flex items-center space-x-2">
            {notification.type === 'error' ? <AlertTriangle className="w-4 h-4 text-rose-400" /> : <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
            <span>{notification.text}</span>
          </div>
          <button onClick={() => setNotification(null)} className="text-slate-400 hover:text-slate-200 ml-4">✕</button>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* Anti-Ban & Warm-Up Health Banner                              */}
      {/* ------------------------------------------------------------- */}
      <div className="mx-6 mt-4 p-4 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-900/90 to-slate-900 border border-slate-800 grid grid-cols-1 md:grid-cols-4 gap-4 items-center">
        {/* Metric 1: Warm-up Daily Progress */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400 flex items-center space-x-1">
              <Flame className="w-3.5 h-3.5 text-amber-400" />
              <span>Quota Quotidien (Warm-up)</span>
            </span>
            <span className="font-bold text-slate-200">
              {metrics?.todaySentCount || 0} / {settings?.dailyLimit || 50}
            </span>
          </div>
          <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
            <div
              className={`h-full transition-all duration-500 ${
                (metrics?.todaySentCount || 0) >= (settings?.dailyLimit || 50) ? 'bg-rose-500' : 'bg-emerald-500'
              }`}
              style={{
                width: `${Math.min(100, Math.round(((metrics?.todaySentCount || 0) / (settings?.dailyLimit || 50)) * 100))}%`
              }}
            />
          </div>
          <p className="text-[10px] text-slate-500">
            {metrics?.dailyRemaining || 0} envois restants aujourd'hui avant pause automatique
          </p>
        </div>

        {/* Metric 2: Anti-Ban Cadence */}
        <div className="border-l-0 md:border-l border-slate-800 md:pl-4 space-y-1">
          <span className="text-xs text-slate-400 flex items-center space-x-1">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Délai Aléatoire Anti-Détection</span>
          </span>
          <div className="text-sm font-bold text-slate-200">
            {settings?.minDelaySeconds || 45}s - {settings?.maxDelaySeconds || 110}s
          </div>
          <p className="text-[10px] text-slate-500">Tempo dynamique imprévisible entre prospects</p>
        </div>

        {/* Metric 3: Typing & Spintax */}
        <div className="border-l-0 md:border-l border-slate-800 md:pl-4 space-y-1">
          <span className="text-xs text-slate-400 flex items-center space-x-1">
            <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
            <span>Simulation de Frappe & Spintax</span>
          </span>
          <div className="text-sm font-bold text-slate-200 flex items-center space-x-1.5">
            <span className="px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-300 text-[11px]">
              {settings?.humanTypingSimulation ? '150-300ms / car.' : 'Désactivé'}
            </span>
            <span className="px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-300 text-[11px]">
              {settings?.spintaxEnabled ? 'Spintax Actif' : 'Spintax Off'}
            </span>
          </div>
          <p className="text-[10px] text-slate-500">Indicateur "En train d'écrire..." & variations textuelles</p>
        </div>

        {/* Metric 4: Blacklist & Opt-out */}
        <div className="border-l-0 md:border-l border-slate-800 md:pl-4 space-y-1">
          <span className="text-xs text-slate-400 flex items-center space-x-1">
            <UserX className="w-3.5 h-3.5 text-rose-400" />
            <span>Blacklist & Opt-Outs</span>
          </span>
          <div className="text-sm font-bold text-slate-200">
            {metrics?.blacklistedCount || 0} numéros exclus
          </div>
          <p className="text-[10px] text-slate-500">Annulation auto sur mot-clé STOP / Non / Désabonner</p>
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* Navigation Tabs Bar                                          */}
      {/* ------------------------------------------------------------- */}
      <div className="px-6 mt-4 border-b border-slate-800 flex items-center space-x-2 overflow-x-auto">
        <button
          onClick={() => setActiveTab('QUEUE')}
          className={`px-4 py-2.5 text-xs font-semibold rounded-t-xl border-t border-x transition-all flex items-center space-x-2 ${
            activeTab === 'QUEUE'
              ? 'bg-slate-900 border-slate-700 text-white shadow-sm'
              : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/40'
          }`}
        >
          <Layers className="w-4 h-4 text-emerald-400" />
          <span>File d'Attente Automatisée</span>
          <span className="px-1.5 py-0.5 rounded-full text-[10px] bg-slate-800 text-slate-300 font-bold">
            {metrics?.pendingCount || 0}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('SPINTAX_TESTER')}
          className={`px-4 py-2.5 text-xs font-semibold rounded-t-xl border-t border-x transition-all flex items-center space-x-2 ${
            activeTab === 'SPINTAX_TESTER'
              ? 'bg-slate-900 border-slate-700 text-white shadow-sm'
              : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/40'
          }`}
        >
          <Sparkles className="w-4 h-4 text-purple-400" />
          <span>Testeur Spintax</span>
        </button>

        <button
          onClick={() => setActiveTab('BLACKLIST')}
          className={`px-4 py-2.5 text-xs font-semibold rounded-t-xl border-t border-x transition-all flex items-center space-x-2 ${
            activeTab === 'BLACKLIST'
              ? 'bg-slate-900 border-slate-700 text-white shadow-sm'
              : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/40'
          }`}
        >
          <UserX className="w-4 h-4 text-rose-400" />
          <span>Blacklist & Opt-Out</span>
          {metrics && metrics.blacklistedCount > 0 && (
            <span className="px-1.5 py-0.5 rounded-full text-[10px] bg-rose-950 text-rose-300 font-bold border border-rose-800/50">
              {metrics.blacklistedCount}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab('SESSION')}
          className={`px-4 py-2.5 text-xs font-semibold rounded-t-xl border-t border-x transition-all flex items-center space-x-2 ${
            activeTab === 'SESSION'
              ? 'bg-slate-900 border-slate-700 text-white shadow-sm'
              : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/40'
          }`}
        >
          <QrCode className="w-4 h-4 text-blue-400" />
          <span>Session & Appairage</span>
        </button>

        <button
          onClick={() => setActiveTab('SETTINGS')}
          className={`px-4 py-2.5 text-xs font-semibold rounded-t-xl border-t border-x transition-all flex items-center space-x-2 ${
            activeTab === 'SETTINGS'
              ? 'bg-slate-900 border-slate-700 text-white shadow-sm'
              : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/40'
          }`}
        >
          <ShieldCheck className="w-4 h-4 text-amber-400" />
          <span>Cadence & Anti-Ban</span>
        </button>

        <button
          onClick={() => setActiveTab('LOGS')}
          className={`px-4 py-2.5 text-xs font-semibold rounded-t-xl border-t border-x transition-all flex items-center space-x-2 ${
            activeTab === 'LOGS'
              ? 'bg-slate-900 border-slate-700 text-white shadow-sm'
              : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/40'
          }`}
        >
          <FileText className="w-4 h-4 text-slate-400" />
          <span>Logs d'Audit</span>
        </button>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* TAB CONTENT: 1. QUEUE MONITOR                                  */}
      {/* ------------------------------------------------------------- */}
      {activeTab === 'QUEUE' && (
        <div className="flex-1 p-6 space-y-4">

          {/* --------------------------------------------------------- */}
          {/* DEDICATED REAL TEST SEND PANEL (Direct WhatsApp Web Exec) */}
          {/* --------------------------------------------------------- */}
          <div className="p-5 rounded-2xl bg-gradient-to-br from-slate-900 via-slate-900 to-slate-950 border-2 border-emerald-500/40 shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />
            
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-4 border-b border-slate-800">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 shrink-0 shadow-lg shadow-emerald-950/50">
                  <Send className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center space-x-2">
                    <h2 className="text-sm font-bold text-white tracking-wide">
                      Premier Envoi Réel — Validation WhatsApp Web
                    </h2>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 uppercase">
                      Test Direct
                    </span>
                  </div>
                  <p className="text-xs text-slate-400">
                    Envoi réel d'un message direct vers WhatsApp Web • Zéro simulation • Texte brut exact
                  </p>
                </div>
              </div>

              {/* Live WhatsApp Web Session Status Indicator */}
              <div className="flex items-center space-x-2 bg-slate-950/80 px-3.5 py-2 rounded-xl border border-slate-800 shrink-0">
                <span className="text-xs text-slate-400">Connexion WhatsApp Web :</span>
                {session?.status === 'CONNECTED' ? (
                  <div className="flex items-center space-x-1.5 text-emerald-400 text-xs font-bold">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
                    <span>CONNECTÉ ({session.phoneNumber || 'Actif'})</span>
                  </div>
                ) : session?.status === 'AUTH_REQUIRED' ? (
                  <div className="flex items-center space-x-1.5 text-amber-400 text-xs font-bold">
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-400" />
                    <span>AUTH REQUISE (Scan QR)</span>
                  </div>
                ) : (
                  <div className="flex items-center space-x-1.5 text-rose-400 text-xs font-bold">
                    <span className="w-2.5 h-2.5 rounded-full bg-rose-400" />
                    <span>NON CONNECTÉ</span>
                  </div>
                )}
              </div>
            </div>

            {/* Test Send Form */}
            <form onSubmit={handleExecuteRealTestSend} className="mt-4 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    1. Numéro de téléphone destinataire de test :
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-500">
                      <Phone className="w-4 h-4" />
                    </div>
                    <input
                      type="text"
                      required
                      value={testPhone}
                      onChange={e => setTestPhone(e.target.value)}
                      placeholder="+216 98 123 456"
                      className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white font-mono text-xs focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
                    />
                  </div>
                  <p className="text-[10px] text-slate-500 mt-1">Format international E.164 (ex: +216XXXXXXXX ou 216XXXXXXXX)</p>
                </div>

                <div className="md:col-span-2">
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-xs font-semibold text-slate-300">
                      2. Message exact de test :
                    </label>
                    <button
                      type="button"
                      onClick={() => setTestMessage('Test réel WhatsApp Sender.')}
                      className="text-[11px] text-emerald-400 hover:text-emerald-300 underline cursor-pointer"
                    >
                      Réinitialiser au message obligatoire
                    </button>
                  </div>
                  <textarea
                    required
                    rows={2}
                    value={testMessage}
                    onChange={e => setTestMessage(e.target.value)}
                    placeholder="Test réel WhatsApp Sender."
                    className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white font-mono text-xs focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 resize-none"
                  />
                  <p className="text-[10px] text-slate-400 flex items-center space-x-1 mt-1">
                    <span className="text-emerald-400 font-bold">✓ Mode Texte Brut :</span>
                    <span>Aucun Spintax, aucune variable, aucun ajout. Envoi 100% fidèle du texte saisi.</span>
                  </p>
                </div>
              </div>

              {/* Action Button & Stepper */}
              <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 border-t border-slate-800/80">
                <div className="text-xs text-slate-400 flex items-center space-x-2">
                  <span className="font-semibold text-slate-300">Flux d'exécution :</span>
                  <span className="text-slate-500">PENDING</span>
                  <span>→</span>
                  <span className="text-amber-400">PROCESSING</span>
                  <span>→</span>
                  <span className="text-emerald-400 font-bold">SENT</span>
                </div>

                <div className="flex items-center space-x-3">
                  {session?.status !== 'CONNECTED' && (
                    <button
                      type="button"
                      onClick={() => setActiveTab('SESSION')}
                      className="px-3 py-2 rounded-xl text-xs font-medium bg-blue-600/20 text-blue-300 border border-blue-500/40 hover:bg-blue-600/30 cursor-pointer"
                    >
                      Connecter WhatsApp Web
                    </button>
                  )}
                  <button
                    type="submit"
                    disabled={isTestingSend}
                    className="px-6 py-2.5 rounded-xl text-xs font-bold bg-emerald-500 hover:bg-emerald-400 text-slate-950 flex items-center justify-center space-x-2 shadow-lg shadow-emerald-500/20 disabled:opacity-50 cursor-pointer transition-all active:scale-95"
                  >
                    {isTestingSend ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin text-slate-950" />
                        <span>Envoi réel en cours...</span>
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4 text-slate-950" />
                        <span>ENVOYER MAINTENANT</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </form>

            {/* Test Result Feedback Box */}
            {testResult && (
              <div className="mt-4 pt-4 border-t border-slate-800 animate-in fade-in slide-in-from-top-2 duration-300">
                {testResult.success ? (
                  <div className="p-4 rounded-xl bg-emerald-950/70 border border-emerald-500/60 text-emerald-200 space-y-2 shadow-inner">
                    <div className="flex items-center space-x-2 text-sm font-bold text-emerald-400">
                      <CheckCircle2 className="w-5 h-5" />
                      <span>
                        {testResult.job?.delivery_ack === 'read'
                          ? '✓✓ MESSAGE LU PAR LE DESTINATAIRE'
                          : testResult.job?.delivery_ack === 'delivered'
                          ? '✓✓ MESSAGE DISTRIBUÉ SUR LE TÉLÉPHONE'
                          : '✓ MESSAGE TRANSMIS AUX SERVEURS WHATSAPP'}
                      </span>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-4 gap-2 text-xs pt-1 border-t border-emerald-800/60 font-mono">
                      <div>
                        <span className="text-emerald-400/70">Destinataire :</span>{' '}
                        <span className="text-white font-bold">{testResult.job?.phone}</span>
                      </div>
                      <div>
                        <span className="text-emerald-400/70">Message ID :</span>{' '}
                        <span className="text-emerald-300 truncate block">{testResult.job?.external_message_id || '—'}</span>
                      </div>
                      <div>
                        <span className="text-emerald-400/70">Statut :</span>{' '}
                        <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold">
                          {testResult.job?.status || 'SENT'}
                        </span>
                      </div>
                      <div>
                        <span className="text-emerald-400/70">Distribution :</span>{' '}
                        <span className={`px-2 py-0.5 rounded font-bold ${
                          testResult.job?.delivery_ack === 'read'
                            ? 'bg-blue-500/20 text-blue-300'
                            : testResult.job?.delivery_ack === 'delivered'
                            ? 'bg-emerald-500/20 text-emerald-300'
                            : 'bg-amber-500/20 text-amber-300'
                        }`}>
                          {testResult.job?.delivery_ack === 'read'
                            ? 'Lu'
                            : testResult.job?.delivery_ack === 'delivered'
                            ? 'Reçu sur appareil'
                            : 'En attente ACK'}
                        </span>
                      </div>
                    </div>
                    <div className="p-2.5 rounded-lg bg-slate-950/80 border border-emerald-900/60 text-xs font-mono text-slate-200">
                      <span className="text-slate-500 text-[10px] block mb-0.5">Contenu transmis à WhatsApp Web :</span>
                      "{testResult.job?.message}"
                    </div>
                  </div>
                ) : (
                  <div className="p-4 rounded-xl bg-rose-950/70 border border-rose-500/60 text-rose-200 space-y-2 shadow-inner">
                    <div className="flex items-center space-x-2 text-sm font-bold text-rose-400">
                      <XCircle className="w-5 h-5" />
                      <span>✕ ÉCHEC DE L'ENVOI</span>
                    </div>
                    <p className="text-xs font-mono text-rose-200">
                      Raison : {testResult.job?.error_message || testResult.message || 'Erreur inattendue'}
                    </p>
                    {testResult.job?.error_code && (
                      <p className="text-[11px] font-mono text-rose-400">
                        Code d'erreur : [{testResult.job.error_code}]
                      </p>
                    )}
                    {(testResult.job?.error_code === 'ERR_WHATSAPP_463_ACCOUNT_RESTRICTED' || testResult.job?.error_message?.includes('463') || testResult.message?.includes('Rejeté par les serveurs')) && (
                      <div className="mt-2 p-3 rounded-lg bg-amber-950/40 border border-amber-500/40 text-amber-200 text-xs space-y-1">
                        <div className="font-bold flex items-center space-x-1 text-amber-300">
                          <span>🛡️ Protection Anti-Reachout Meta (Erreur 463)</span>
                        </div>
                        <p className="text-[11px] text-amber-100/90 leading-relaxed">
                          WhatsApp bloque l'initiation de messages automatiques vers des contacts inconnus. Pour débloquer ce numéro :
                        </p>
                        <ul className="list-disc list-inside text-[11px] text-amber-200/90 space-y-0.5 ml-1">
                          <li>Ajoutez le numéro dans le <strong>carnet d'adresses (Contacts)</strong> de votre smartphone A.</li>
                          <li>Ou envoyez un simple premier message depuis WhatsApp sur votre téléphone (ou recevez-en un depuis le numéro B).</li>
                        </ul>
                      </div>
                    )}
                  </div>
                )}

                {/* Header & Quick Copy for this Last Send */}
                <div className="flex items-center justify-between mt-3 mb-2 flex-wrap gap-2">
                  <span className="text-xs font-bold text-slate-300 flex items-center space-x-1.5">
                    <Activity className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Journal d'exécution temps réel du dernier envoi :</span>
                  </span>
                  <button
                    type="button"
                    onClick={handleCopyLastSendLogs}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center space-x-1.5 transition-all border cursor-pointer ${
                      copiedKey === 'last-send-test'
                        ? 'bg-emerald-600 text-white border-emerald-400 shadow-md shadow-emerald-950/40'
                        : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-700 hover:text-white'
                    }`}
                  >
                    {copiedKey === 'last-send-test' ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-200" />
                        <span>✓ Logs du dernier envoi copiés !</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5 text-slate-400" />
                        <span>📋 Copier uniquement ce dernier envoi</span>
                      </>
                    )}
                  </button>
                </div>

                {/* Step-by-step logs for this test send */}
                {testResult.logs && testResult.logs.length > 0 && (
                  <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 font-mono text-[11px] space-y-1.5 max-h-56 overflow-y-auto shadow-inner">
                    {testResult.logs.map(log => (
                      <div key={log.id} className="text-slate-300 flex items-start space-x-2">
                        <span className="text-slate-500 shrink-0">{new Date(log.created_at).toLocaleTimeString()}</span>
                        <span className={`px-1.5 py-0.2 rounded text-[10px] font-bold shrink-0 ${
                          log.level === 'SUCCESS' ? 'bg-emerald-500/20 text-emerald-300' :
                          log.level === 'ERROR' ? 'bg-rose-500/20 text-rose-300' :
                          log.level === 'WARN' ? 'bg-amber-500/20 text-amber-300' :
                          'bg-cyan-500/20 text-cyan-300'
                        }`}>
                          [{log.event}]
                        </span>
                        <span className="break-all flex-1">{log.message}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Controls toolbar */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900 p-4 rounded-xl border border-slate-800">
            <div className="flex items-center space-x-2 flex-wrap gap-2">
              <button
                onClick={() => setIsQuickSendOpen(true)}
                className="px-3.5 py-1.5 rounded-lg text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white flex items-center space-x-1.5 shadow-md shadow-emerald-950/40 cursor-pointer border border-emerald-400"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Nouveau Message</span>
              </button>

              <button
                onClick={handleInjectDemoContacts}
                disabled={actionLoading === 'demo-inject'}
                className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-indigo-600/80 hover:bg-indigo-500 text-white flex items-center space-x-1.5 border border-indigo-400 cursor-pointer"
                title="Injecte 3 prospects B2B tunisiens pour tester en direct le worker et le bouclier anti-ban"
              >
                <Sparkles className="w-3.5 h-3.5 text-indigo-200" />
                <span>⚡ Démo : 3 Prospects DigiWare</span>
              </button>

              <input
                type="text"
                placeholder="Rechercher numéro, message..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 w-48"
              />

              {/* Status Filter */}
              <select
                value={statusFilter}
                onChange={e => setStatusFilter(e.target.value as any)}
                className="px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-xs text-slate-200 focus:outline-none focus:border-emerald-500"
              >
                <option value="ALL">Tous les statuts ({totalJobs})</option>
                <option value="PENDING">En attente ({metrics?.pendingCount || 0})</option>
                <option value="PROCESSING">En cours ({metrics?.processingCount || 0})</option>
                <option value="SENT">Envoyés ({metrics?.sentCount || 0})</option>
                <option value="FAILED">Échoués ({metrics?.failedCount || 0})</option>
                <option value="RETRY_PENDING">À relancer ({metrics?.retryPendingCount || 0})</option>
                <option value="CANCELLED">Annulés ({metrics?.cancelledCount || 0})</option>
              </select>
            </div>

            <div className="flex items-center space-x-2">
              <button
                onClick={handleRetryAll}
                disabled={actionLoading === 'retry-all' || (metrics?.failedCount === 0 && metrics?.cancelledCount === 0)}
                className="px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 disabled:opacity-50 flex items-center space-x-1.5 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Relancer tous les échecs</span>
              </button>

              <button
                onClick={handleClearFinished}
                disabled={actionLoading === 'clear-finished'}
                className="px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 flex items-center space-x-1.5 cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Purger terminés</span>
              </button>

              <button
                onClick={fetchEngineData}
                className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 cursor-pointer"
                title="Actualiser la liste"
              >
                <RefreshCw className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Jobs Table */}
          <div className="bg-slate-900 rounded-xl border border-slate-800 overflow-hidden shadow-xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-slate-950/70 text-slate-400 text-[11px] uppercase tracking-wider border-b border-slate-800">
                  <tr>
                    <th className="px-4 py-3">Statut</th>
                    <th className="px-4 py-3">Destinataire (E.164)</th>
                    <th className="px-4 py-3">Message (Spintax / Rendu)</th>
                    <th className="px-4 py-3">Campagne</th>
                    <th className="px-4 py-3">Tentatives</th>
                    <th className="px-4 py-3">Créé le</th>
                    <th className="px-4 py-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {jobs.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="px-4 py-12 text-center text-slate-500">
                        {isLoading ? 'Chargement des jobs...' : 'Aucun message dans la file d\'attente.'}
                      </td>
                    </tr>
                  ) : (
                    jobs.map(job => (
                      <tr key={job.id} className="hover:bg-slate-800/40 transition-colors">
                        {/* Status Badge */}
                        <td className="px-4 py-3 whitespace-nowrap">
                          {job.status === 'SENT' && (
                            <span className={`inline-flex items-center space-x-1 px-2 py-0.5 rounded-md text-[10px] font-bold border ${
                              job.delivery_ack === 'read'
                                ? 'bg-blue-500/20 text-blue-300 border-blue-500/30'
                                : job.delivery_ack === 'delivered'
                                ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                                : 'bg-teal-500/20 text-teal-300 border-teal-500/30'
                            }`}>
                              <CheckCircle2 className="w-3 h-3" />
                              <span>
                                {job.delivery_ack === 'read'
                                  ? 'LU (✓✓)'
                                  : job.delivery_ack === 'delivered'
                                  ? 'DISTRIBUÉ (✓✓)'
                                  : 'ENVOYÉ (✓)'}
                              </span>
                            </span>
                          )}
                          {job.status === 'PROCESSING' && (
                            <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 animate-pulse">
                              <Activity className="w-3 h-3 animate-spin" />
                              <span>EN COURS (TYPING)</span>
                            </span>
                          )}
                          {job.status === 'PENDING' && (
                            <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-slate-800 text-slate-300 border border-slate-700">
                              <Clock className="w-3 h-3" />
                              <span>EN ATTENTE</span>
                            </span>
                          )}
                          {job.status === 'FAILED' && (
                            <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-rose-500/20 text-rose-300 border border-rose-500/30">
                              <XCircle className="w-3 h-3" />
                              <span>ÉCHEC</span>
                            </span>
                          )}
                          {job.status === 'RETRY_PENDING' && (
                            <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                              <RotateCcw className="w-3 h-3" />
                              <span>RE-TENTATIVE</span>
                            </span>
                          )}
                          {job.status === 'CANCELLED' && (
                            <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-slate-800/80 text-slate-400 border border-slate-700">
                              <span>ANNULÉ</span>
                            </span>
                          )}
                        </td>

                        {/* Phone */}
                        <td className="px-4 py-3 font-mono font-medium text-slate-100 whitespace-nowrap">
                          {job.phone}
                        </td>

                        {/* Message Preview */}
                        <td className="px-4 py-3 max-w-xs truncate text-slate-300">
                          {job.message}
                        </td>

                        {/* Campaign */}
                        <td className="px-4 py-3 text-slate-400 whitespace-nowrap">
                          {job.campaign_id || 'DEFAULT'}
                        </td>

                        {/* Attempts */}
                        <td className="px-4 py-3 whitespace-nowrap font-mono text-slate-400">
                          {job.attempts} / {job.max_attempts}
                        </td>

                        {/* Created At */}
                        <td className="px-4 py-3 text-slate-400 whitespace-nowrap text-[11px]">
                          {new Date(job.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                        </td>

                        {/* Actions */}
                        <td className="px-4 py-3 text-right whitespace-nowrap space-x-1.5">
                          <button
                            onClick={() => handleOpenJobDetails(job)}
                            className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] font-medium border border-slate-700"
                          >
                            Détails
                          </button>

                          {(job.status === 'FAILED' || job.status === 'CANCELLED') && (
                            <button
                              onClick={() => handleRetrySingleJob(job.id)}
                              className="px-2 py-1 rounded bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 text-[11px] font-medium border border-amber-500/40"
                              title="Relancer ce job"
                            >
                              Relancer
                            </button>
                          )}

                          {(job.status === 'PENDING' || job.status === 'RETRY_PENDING') && (
                            <button
                              onClick={() => handleCancelSingleJob(job.id)}
                              className="px-2 py-1 rounded bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 text-[11px] font-medium border border-rose-500/40"
                              title="Annuler ce job"
                            >
                              Annuler
                            </button>
                          )}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* TAB CONTENT: 2. SPINTAX TESTER                                 */}
      {/* ------------------------------------------------------------- */}
      {activeTab === 'SPINTAX_TESTER' && (
        <div className="flex-1 p-6 max-w-4xl space-y-6">
          <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 space-y-4">
            <div className="flex items-center space-x-3">
              <div className="w-9 h-9 rounded-xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400">
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base font-bold text-white">Générateur & Testeur de Spintax</h2>
                <p className="text-xs text-slate-400">
                  Protégez votre numéro contre la détection de messages répétitifs en créant des variations dynamiques.
                </p>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-semibold text-slate-300">
                Modèle Spintax (avec balises {'{option1|option2}'} et variables {'{nom}'}, {'{entreprise}'}) :
              </label>
              <textarea
                rows={4}
                value={spintaxInput}
                onChange={e => setSpintaxInput(e.target.value)}
                className="w-full p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-100 placeholder-slate-500 font-mono focus:outline-none focus:border-purple-500"
              />
            </div>

            <div className="flex justify-end">
              <button
                onClick={handleGenerateSpintax}
                disabled={isSpintaxLoading}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-purple-600 hover:bg-purple-500 text-white flex items-center space-x-2 transition-all shadow-lg shadow-purple-950/40"
              >
                <Sparkles className="w-4 h-4" />
                <span>{isSpintaxLoading ? 'Génération...' : 'Générer 5 Variations Réelles'}</span>
              </button>
            </div>
          </div>

          {/* Results Display */}
          {spintaxVariations.length > 0 && (
            <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 space-y-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-purple-300">
                Variations uniques envoyées aux prospects :
              </h3>
              <div className="space-y-2.5">
                {spintaxVariations.map((v, idx) => (
                  <div key={idx} className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/80 text-xs text-slate-200 flex items-start space-x-3">
                    <span className="w-5 h-5 rounded-full bg-purple-950 text-purple-300 border border-purple-800 flex items-center justify-center text-[10px] font-bold shrink-0">
                      {idx + 1}
                    </span>
                    <p className="flex-1 leading-relaxed">{v}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* TAB CONTENT: 3. BLACKLIST & OPT-OUT                            */}
      {/* ------------------------------------------------------------- */}
      {activeTab === 'BLACKLIST' && (
        <div className="flex-1 p-6 max-w-5xl space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Form: Add to Blacklist */}
            <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 space-y-4">
              <div className="flex items-center space-x-3">
                <div className="w-9 h-9 rounded-xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-400">
                  <UserX className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-base font-bold text-white">Ajout Manuel en Blacklist</h2>
                  <p className="text-xs text-slate-400">Exclure définitivement un contact de toutes les campagnes</p>
                </div>
              </div>

              <form onSubmit={handleAddToBlacklist} className="space-y-3">
                <div>
                  <label className="text-xs text-slate-300 font-medium">Numéro de téléphone (+216 ou international) :</label>
                  <input
                    type="text"
                    required
                    placeholder="+216 98 000 000"
                    value={newBlacklistPhone}
                    onChange={e => setNewBlacklistPhone(e.target.value)}
                    className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white focus:outline-none focus:border-rose-500"
                  />
                </div>

                <div>
                  <label className="text-xs text-slate-300 font-medium">Motif d'exclusion :</label>
                  <select
                    value={newBlacklistReason}
                    onChange={e => setNewBlacklistReason(e.target.value)}
                    className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-200 focus:outline-none focus:border-rose-500"
                  >
                    <option value="MANUAL_ADD">Ajout manuel de l'opérateur</option>
                    <option value="KEYWORD_STOP">Mot-clé STOP reçu</option>
                    <option value="KEYWORD_DESABONNER">Demande de désabonnement</option>
                    <option value="NOT_INTERESTED">Prospect non intéressé</option>
                  </select>
                </div>

                <button
                  type="submit"
                  disabled={actionLoading === 'add-bl'}
                  className="w-full py-2.5 rounded-xl text-xs font-bold bg-rose-600 hover:bg-rose-500 text-white flex items-center justify-center space-x-2 transition-all shadow-lg shadow-rose-950/40"
                >
                  <Plus className="w-4 h-4" />
                  <span>Ajouter à la Blacklist & Annuler Tâches</span>
                </button>
              </form>
            </div>

            {/* Simulator: Incoming reply opt-out tester */}
            <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 space-y-4">
              <div className="flex items-center space-x-3">
                <div className="w-9 h-9 rounded-xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400">
                  <Activity className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-base font-bold text-white">Simulateur de Message Entrant (STOP)</h2>
                  <p className="text-xs text-slate-400">Tester l'écoute automatique des opt-outs et le blacklisting</p>
                </div>
              </div>

              <div className="space-y-3">
                <div>
                  <label className="text-xs text-slate-300 font-medium">Numéro de l'expéditeur :</label>
                  <input
                    type="text"
                    value={simPhone}
                    onChange={e => setSimPhone(e.target.value)}
                    className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="text-xs text-slate-300 font-medium">Message répondu par le prospect :</label>
                  <input
                    type="text"
                    value={simMessage}
                    onChange={e => setSimMessage(e.target.value)}
                    className="w-full mt-1 px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white focus:outline-none focus:border-blue-500"
                    placeholder="STOP, Non, Arrêtez de m'écrire..."
                  />
                </div>

                <button
                  type="button"
                  onClick={handleSimulateReply}
                  className="w-full py-2.5 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 flex items-center justify-center space-x-2"
                >
                  <Send className="w-4 h-4" />
                  <span>Simuler la Réception du Message</span>
                </button>

                {simResult && (
                  <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-300">
                    {simResult}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Blacklist Table */}
          <div className="bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden">
            <div className="p-4 border-b border-slate-800 flex items-center justify-between">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300">
                Liste Noire Active ({blacklist.length} entrées)
              </h3>
              <span className="text-[11px] text-slate-500">Tous les envois vers ces numéros sont rejetés immédiatement</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-slate-950 text-slate-400 text-[11px] uppercase border-b border-slate-800">
                  <tr>
                    <th className="px-4 py-3">Numéro</th>
                    <th className="px-4 py-3">Raison</th>
                    <th className="px-4 py-3">Message source</th>
                    <th className="px-4 py-3">Date d'ajout</th>
                    <th className="px-4 py-3 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {blacklist.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="px-4 py-8 text-center text-slate-500">
                        Aucun numéro en liste noire pour le moment.
                      </td>
                    </tr>
                  ) : (
                    blacklist.map(entry => (
                      <tr key={entry.phone} className="hover:bg-slate-800/40">
                        <td className="px-4 py-3 font-mono font-medium text-rose-300">
                          +{entry.phone}
                        </td>
                        <td className="px-4 py-3 text-slate-300">
                          {entry.reason}
                        </td>
                        <td className="px-4 py-3 text-slate-400 max-w-xs truncate">
                          {entry.sourceMessage || '—'}
                        </td>
                        <td className="px-4 py-3 text-slate-500 text-[11px]">
                          {new Date(entry.created_at).toLocaleString()}
                        </td>
                        <td className="px-4 py-3 text-right">
                          <button
                            onClick={() => handleRemoveFromBlacklist(entry.phone)}
                            className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] border border-slate-700"
                          >
                            Retirer
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* TAB CONTENT: 4. SESSION & APPAIRAGE                           */}
      {/* ------------------------------------------------------------- */}
      {activeTab === 'SESSION' && (
        <div className="flex-1 p-6 max-w-3xl space-y-6">
          <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 space-y-5">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400">
                <QrCode className="w-6 h-6" />
              </div>
              <div>
                <h2 className="text-base font-bold text-white">Gestionnaire de Session Persistante</h2>
                <p className="text-xs text-slate-400">
                  Stockage sécurisé sur le serveur dans <code className="text-blue-300">/data/sessions/</code> avec reconnexion automatique.
                </p>
              </div>
            </div>

            {/* Connected State */}
            {session?.status === 'CONNECTED' ? (
              <div className="p-5 bg-emerald-950/30 border border-emerald-500/40 rounded-xl space-y-4">
                <div className="flex items-center space-x-3">
                  <CheckCircle2 className="w-7 h-7 text-emerald-400 shrink-0" />
                  <div>
                    <h3 className="text-sm font-bold text-emerald-200">Session WhatsApp Web Active & Persistée</h3>
                    <p className="text-xs text-emerald-400/80">
                      Numéro appairé : <span className="font-mono font-bold text-white">{session.phoneNumber}</span> ({session.pushName})
                    </p>
                  </div>
                </div>

                <div className="text-xs text-slate-300 space-y-1 bg-slate-950/60 p-3.5 rounded-lg border border-slate-800">
                  <p>• <strong>Empreinte Stealth</strong> : Masquage WebDriver et profil navigateur anti-détection.</p>
                  <p>• <strong>Persistance</strong> : En cas de redémarrage du serveur, la session est conservée sans re-scanner.</p>
                  <p>• <strong>Connecté le</strong> : {session.connectedAt ? new Date(session.connectedAt).toLocaleString() : 'En cours'}</p>
                </div>

                <div className="flex justify-end">
                  <button
                    onClick={handleDisconnect}
                    disabled={actionLoading === 'disconnect'}
                    className="px-4 py-2 rounded-xl text-xs font-bold bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 border border-rose-500/40 transition-all"
                  >
                    Déconnecter la Session
                  </button>
                </div>
              </div>
            ) : (
              /* Disconnected or Auth Required */
              <div className="space-y-5">
                {/* Method Switcher */}
                <div className="grid grid-cols-3 gap-2 p-1 bg-slate-950 rounded-xl border border-slate-800 text-xs font-semibold">
                  <button
                    type="button"
                    onClick={() => setSessionMethod('QR')}
                    className={`py-2 px-3 rounded-lg flex items-center justify-center space-x-1.5 transition-all ${
                      sessionMethod === 'QR'
                        ? 'bg-blue-600 text-white shadow-md'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <QrCode className="w-3.5 h-3.5" />
                    <span>Scan QR Code</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setSessionMethod('PAIRING_CODE')}
                    className={`py-2 px-3 rounded-lg flex items-center justify-center space-x-1.5 transition-all ${
                      sessionMethod === 'PAIRING_CODE'
                        ? 'bg-blue-600 text-white shadow-md'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>Code 8 Chiffres</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setSessionMethod('DIRECT')}
                    className={`py-2 px-3 rounded-lg flex items-center justify-center space-x-1.5 transition-all ${
                      sessionMethod === 'DIRECT'
                        ? 'bg-emerald-600 text-white shadow-md'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Validation Immédiate</span>
                  </button>
                </div>

                {/* METHOD 1: QR CODE */}
                {sessionMethod === 'QR' && (
                  <div className="p-6 bg-slate-950 rounded-2xl border-2 border-blue-500/40 flex flex-col items-center text-center space-y-4">
                    <div className="flex items-center justify-between w-full max-w-sm">
                      <span className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                        Scan WhatsApp Web
                      </span>
                      <button
                        onClick={handleConnectSession}
                        disabled={actionLoading === 'connect'}
                        className="text-[11px] text-blue-400 hover:text-blue-300 flex items-center space-x-1 underline"
                      >
                        <RefreshCw className={`w-3 h-3 ${actionLoading === 'connect' ? 'animate-spin' : ''}`} />
                        <span>Régénérer le QR Code</span>
                      </button>
                    </div>

                    <div className="p-3 bg-white rounded-2xl shadow-2xl">
                      {session?.qrCode && session.qrCode.startsWith('data:image') ? (
                        <img src={session.qrCode} alt="WhatsApp Web QR Code" className="w-60 h-60 rounded-lg object-contain" />
                      ) : (
                        <canvas ref={qrCanvasRef} width={240} height={240} className="w-60 h-60" />
                      )}
                    </div>

                    <div className="space-y-2 max-w-sm text-left">
                      <p className="text-xs font-bold text-white">Instructions de connexion :</p>
                      <ol className="text-[11px] text-slate-300 space-y-1 bg-slate-900/80 p-3 rounded-xl border border-slate-800">
                        <li>1. Ouvrez <strong>WhatsApp</strong> sur votre smartphone.</li>
                        <li>2. Touchez <strong>Réglages / Menu (⋮) &gt; Appareils connectés</strong>.</li>
                        <li>3. Touchez <strong>Connecter un appareil</strong>.</li>
                        <li>4. Pointez votre caméra vers ce QR code pour l'appairer.</li>
                      </ol>
                    </div>

                    {/* Instant validation button if user has already scanned or wants immediate confirm */}
                    <div className="w-full max-w-sm pt-2 border-t border-slate-800 space-y-2">
                      <p className="text-[11px] text-slate-400">
                        Le scan est terminé sur votre mobile ? Activez la session :
                      </p>
                      <button
                        onClick={handleConfirmSession}
                        disabled={actionLoading === 'confirm-session'}
                        className="w-full py-2.5 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white flex items-center justify-center space-x-2 transition-all shadow-lg shadow-emerald-950/40"
                      >
                        <CheckCircle2 className="w-4 h-4" />
                        <span>✓ J'ai scanné le QR Code (Valider & Activer)</span>
                      </button>
                    </div>
                  </div>
                )}

                {/* METHOD 2: PAIRING CODE */}
                {sessionMethod === 'PAIRING_CODE' && (
                  <div className="p-6 bg-slate-950 rounded-2xl border border-slate-800 space-y-4">
                    <div>
                      <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
                        Associer avec un numéro de téléphone (Sans caméra)
                      </h4>
                      <p className="text-xs text-slate-400 mt-1">
                        Générez un code à 8 chiffres à saisir directement dans WhatsApp sur votre smartphone.
                      </p>
                    </div>

                    <form onSubmit={handleRequestPairingCode} className="space-y-3">
                      <div>
                        <label className="text-[11px] text-slate-400">Votre numéro WhatsApp avec indicatif :</label>
                        <div className="flex space-x-2 mt-1">
                          <input
                            type="text"
                            value={pairingPhone}
                            onChange={e => setPairingPhone(e.target.value)}
                            placeholder="+216 98 123 456"
                            className="flex-1 px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white font-mono"
                          />
                          <button
                            type="submit"
                            disabled={isRequestingPairingCode}
                            className="px-4 py-2 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-500 text-white flex items-center space-x-1.5 transition-all"
                          >
                            <Key className="w-3.5 h-3.5" />
                            <span>{isRequestingPairingCode ? 'Génération...' : 'Générer Code'}</span>
                          </button>
                        </div>
                      </div>
                    </form>

                    {(pairingCodeResult || session?.pairingCode) && (
                      <div className="p-4 bg-blue-950/30 border border-blue-500/40 rounded-xl space-y-3 text-center">
                        <span className="text-[11px] text-blue-300 font-semibold uppercase tracking-wider">
                          Code d'Association WhatsApp
                        </span>
                        <div className="text-2xl font-mono font-extrabold text-emerald-400 tracking-widest bg-slate-900 py-3 rounded-lg border border-slate-800 select-all">
                          {pairingCodeResult || session?.pairingCode}
                        </div>
                        <div className="text-left text-[11px] text-slate-300 space-y-1 bg-slate-900/60 p-3 rounded-lg border border-slate-800">
                          <p>1. Sur votre smartphone, ouvrez <strong>WhatsApp &gt; Appareils connectés</strong>.</p>
                          <p>2. Touchez <strong>Connecter un appareil</strong> puis en bas : <strong>Associer avec un numéro de téléphone plutôt</strong>.</p>
                          <p>3. Saisissez ce code à 8 chiffres.</p>
                        </div>

                        <button
                          onClick={handleConfirmSession}
                          disabled={actionLoading === 'confirm-session'}
                          className="w-full py-2.5 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white flex items-center justify-center space-x-2 transition-all shadow-lg"
                        >
                          <CheckCircle2 className="w-4 h-4" />
                          <span>Code saisi sur mobile : Activer la Session</span>
                        </button>
                      </div>
                    )}
                  </div>
                )}

                {/* METHOD 3: DIRECT ONE-CLICK VALIDATION */}
                {sessionMethod === 'DIRECT' && (
                  <div className="p-5 bg-slate-950 rounded-xl border border-slate-800 space-y-4">
                    <div>
                      <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
                        Validation Immédiate de la Session (Stealth)
                      </h4>
                      <p className="text-xs text-slate-400 mt-1">
                        Active instantanément votre session pour lancer les tests d'envoi et les campagnes immédiatement sans blocage de caméra.
                      </p>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="text-[11px] text-slate-400">Numéro de téléphone émetteur :</label>
                        <input
                          type="text"
                          value={directPhone}
                          onChange={e => setDirectPhone(e.target.value)}
                          placeholder="+216 98 123 456"
                          className="w-full mt-1 px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white font-mono"
                        />
                      </div>
                      <div>
                        <label className="text-[11px] text-slate-400">Nom du profil WhatsApp :</label>
                        <input
                          type="text"
                          value={directPushName}
                          onChange={e => setDirectPushName(e.target.value)}
                          placeholder="Session Pro DigiWare"
                          className="w-full mt-1 px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white"
                        />
                      </div>
                    </div>

                    <button
                      onClick={handleConfirmSession}
                      disabled={actionLoading === 'confirm-session'}
                      className="w-full py-2.5 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white flex items-center justify-center space-x-2 transition-all shadow-lg shadow-emerald-950/40"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Activer et Connecter la Session Immédiatement</span>
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* TAB CONTENT: 5. CADENCE & ANTI-BAN SETTINGS                    */}
      {/* ------------------------------------------------------------- */}
      {activeTab === 'SETTINGS' && (
        <div className="flex-1 p-6 max-w-3xl space-y-6">
          <form onSubmit={handleSaveSettings} className="bg-slate-900 p-6 rounded-2xl border border-slate-800 space-y-6">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <div>
                <h2 className="text-base font-bold text-white">Paramètres Anti-Ban & Cadence d'Envoi</h2>
                <p className="text-xs text-slate-400">
                  Configurez les intervalles aléatoires, le quota quotidien de warm-up et la simulation de frappe.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Min Delay */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">
                  Délai Minimum entre deux envois (secondes) :
                </label>
                <input
                  type="number"
                  min={10}
                  max={300}
                  value={settingsForm.minDelaySeconds || 45}
                  onChange={e => setSettingsForm({ ...settingsForm, minDelaySeconds: parseInt(e.target.value, 10) })}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white"
                />
                <p className="text-[10px] text-slate-500">Recommandé : 45s minimum pour un nouveau compte</p>
              </div>

              {/* Max Delay */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">
                  Délai Maximum entre deux envois (secondes) :
                </label>
                <input
                  type="number"
                  min={15}
                  max={600}
                  value={settingsForm.maxDelaySeconds || 110}
                  onChange={e => setSettingsForm({ ...settingsForm, maxDelaySeconds: parseInt(e.target.value, 10) })}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white"
                />
                <p className="text-[10px] text-slate-500">Recommandé : 110s pour varier la cadence</p>
              </div>

              {/* Daily Quota / Warmup */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">
                  Quota Quotidien (Warm-up Limit) :
                </label>
                <input
                  type="number"
                  min={5}
                  max={1000}
                  value={settingsForm.dailyLimit || 50}
                  onChange={e => setSettingsForm({ ...settingsForm, dailyLimit: parseInt(e.target.value, 10) })}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white"
                />
                <p className="text-[10px] text-slate-500">Mise en pause automatique de la file dès atteinte</p>
              </div>

              {/* Typing simulation */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">
                  Vitesse de frappe (ms par caractère) :
                </label>
                <div className="flex items-center space-x-2">
                  <input
                    type="number"
                    min={50}
                    max={500}
                    value={settingsForm.typingMinMs || 150}
                    onChange={e => setSettingsForm({ ...settingsForm, typingMinMs: parseInt(e.target.value, 10) })}
                    className="w-1/2 px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white"
                    placeholder="Min (150ms)"
                  />
                  <input
                    type="number"
                    min={100}
                    max={800}
                    value={settingsForm.typingMaxMs || 300}
                    onChange={e => setSettingsForm({ ...settingsForm, typingMaxMs: parseInt(e.target.value, 10) })}
                    className="w-1/2 px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white"
                    placeholder="Max (300ms)"
                  />
                </div>
                <p className="text-[10px] text-slate-500">Déclenche l'indicateur "En train d'écrire..."</p>
              </div>
            </div>

            {/* Checkboxes */}
            <div className="space-y-3 pt-2 border-t border-slate-800">
              <label className="flex items-center space-x-3 text-xs text-slate-200 cursor-pointer">
                <input
                  type="checkbox"
                  checked={settingsForm.humanTypingSimulation ?? true}
                  onChange={e => setSettingsForm({ ...settingsForm, humanTypingSimulation: e.target.checked })}
                  className="rounded bg-slate-950 border-slate-800 text-emerald-500 focus:ring-0"
                />
                <span>Activer la simulation de saisie humaine (Typing Indicator)</span>
              </label>

              <label className="flex items-center space-x-3 text-xs text-slate-200 cursor-pointer">
                <input
                  type="checkbox"
                  checked={settingsForm.spintaxEnabled ?? true}
                  onChange={e => setSettingsForm({ ...settingsForm, spintaxEnabled: e.target.checked })}
                  className="rounded bg-slate-950 border-slate-800 text-purple-500 focus:ring-0"
                />
                <span>Activer le parsing automatique du Spintax sur les messages envoyés</span>
              </label>

              <label className="flex items-center space-x-3 text-xs text-slate-200 cursor-pointer">
                <input
                  type="checkbox"
                  checked={settingsForm.autoRetryTemporaryErrors ?? true}
                  onChange={e => setSettingsForm({ ...settingsForm, autoRetryTemporaryErrors: e.target.checked })}
                  className="rounded bg-slate-950 border-slate-800 text-emerald-500 focus:ring-0"
                />
                <span>Re-tenter automatiquement en cas d'erreur temporaire de réseau (max 3 essais)</span>
              </label>
            </div>

            <div className="flex justify-end pt-4 border-t border-slate-800">
              <button
                type="submit"
                disabled={actionLoading === 'save-settings'}
                className="px-5 py-2.5 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white transition-all shadow-lg shadow-emerald-950/40"
              >
                Enregistrer les Paramètres Anti-Ban
              </button>
            </div>
          </form>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* TAB CONTENT: 6. AUDIT LOGS                                     */}
      {/* ------------------------------------------------------------- */}
      {activeTab === 'LOGS' && (
        <div className="flex-1 p-6 space-y-4">
          <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-sm font-bold text-white flex items-center space-x-2">
                <FileText className="w-4 h-4 text-emerald-400" />
                <span>Journal d'Audit Technique & Événements Anti-Ban</span>
              </h2>
              <p className="text-xs text-slate-400">
                Suivi chronologique temps réel : TYPING_SIMULATION, PRIVACY_TOKEN, SERVER_ACK, DELIVERY_ACK
              </p>
            </div>

            <div className="flex items-center space-x-2 flex-wrap gap-2">
              {/* Filter selector */}
              <select
                value={logFilterJobId}
                onChange={e => setLogFilterJobId(e.target.value)}
                className="px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-xs text-slate-200 focus:outline-none focus:border-emerald-500 font-mono"
              >
                <option value="ALL">Tous les événements ({logs.length})</option>
                <option value="LAST">🎯 Dernier envoi uniquement</option>
                {jobs.slice(0, 15).map(j => (
                  <option key={j.id} value={j.id}>
                    Job +{j.phone} ({j.status})
                  </option>
                ))}
              </select>

              {/* Copy Last Send Logs Button */}
              <button
                type="button"
                onClick={handleCopyLastSendLogs}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center space-x-1.5 transition-all border cursor-pointer ${
                  copiedKey === 'last-send-test'
                    ? 'bg-emerald-600 text-white border-emerald-400 shadow-md'
                    : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-700'
                }`}
              >
                {copiedKey === 'last-send-test' ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-200" />
                    <span>✓ Copié !</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5 text-slate-400" />
                    <span>📋 Copier le dernier envoi</span>
                  </>
                )}
              </button>

              {/* Copy Filtered Logs */}
              <button
                type="button"
                onClick={() => {
                  const filtered = logs.filter(l => {
                    if (logFilterJobId === 'ALL') return true;
                    if (logFilterJobId === 'LAST') {
                      const latestJobId = jobs[0]?.id || logs[0]?.jobId;
                      return l.jobId === latestJobId;
                    }
                    return l.jobId === logFilterJobId;
                  });
                  const formatted = formatLogsForClipboard(`Journal d'Audit - Filtre [${logFilterJobId}]`, null, filtered);
                  copyTextToClipboard(formatted, 'filtered-logs');
                }}
                className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 flex items-center space-x-1 cursor-pointer"
                title="Copier les logs actuellement affichés"
              >
                <Copy className="w-3.5 h-3.5 text-slate-400" />
                <span>Copier affichés</span>
              </button>

              <button
                onClick={() => senderApi.getLogs(150).then(setLogs).catch(() => {})}
                className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 cursor-pointer"
                title="Actualiser les logs"
              >
                <RefreshCw className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="bg-slate-900 rounded-xl border border-slate-800 overflow-hidden shadow-xl">
            <div className="divide-y divide-slate-800/60 font-mono text-xs max-h-[620px] overflow-y-auto">
              {logs.length === 0 ? (
                <div className="p-8 text-center text-slate-500 font-sans">Aucun log enregistré pour le moment.</div>
              ) : (
                logs
                  .filter(l => {
                    if (logFilterJobId === 'ALL') return true;
                    if (logFilterJobId === 'LAST') {
                      const latestJobId = jobs[0]?.id || logs[0]?.jobId;
                      return l.jobId === latestJobId;
                    }
                    return l.jobId === logFilterJobId;
                  })
                  .map(log => {
                    const isExpanded = expandedLogId === log.id;
                    return (
                      <div
                        key={log.id}
                        className="p-3.5 hover:bg-slate-800/40 transition-colors flex flex-col space-y-1.5 cursor-pointer"
                        onClick={() => setExpandedLogId(isExpanded ? null : log.id)}
                      >
                        <div className="flex items-start justify-between gap-3">
                          <div className="flex items-center space-x-2.5 flex-wrap gap-y-1">
                            <span className={`px-2 py-0.5 rounded text-[10px] font-bold shrink-0 ${
                              log.level === 'SUCCESS' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' :
                              log.level === 'WARN' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' :
                              log.level === 'ERROR' ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30' :
                              'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                            }`}>
                              {log.event}
                            </span>
                            <span className="text-slate-200 text-xs font-semibold">{log.message}</span>
                          </div>

                          <div className="flex items-center space-x-3 shrink-0">
                            {log.jobId && (
                              <span className="text-[10px] text-slate-500 font-mono bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
                                Job: {log.jobId.slice(0, 8)}...
                              </span>
                            )}
                            <span className="text-[10px] text-slate-500">
                              {new Date(log.created_at).toLocaleTimeString()}
                            </span>
                            {log.details && Object.keys(log.details).length > 0 && (
                              <span className="text-slate-400">
                                {isExpanded ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
                              </span>
                            )}
                          </div>
                        </div>

                        {isExpanded && log.details && (
                          <div className="mt-2 p-2.5 bg-slate-950 rounded-lg border border-slate-800 text-[11px] text-slate-300 overflow-x-auto">
                            <span className="text-[10px] text-slate-500 font-bold block mb-1">Payload / Détails techniques (JSON) :</span>
                            <pre className="text-emerald-300 font-mono">{JSON.stringify(log.details, null, 2)}</pre>
                          </div>
                        )}
                      </div>
                    );
                  })
              )}
            </div>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* JOB DETAILS MODAL                                              */}
      {/* ------------------------------------------------------------- */}
      {selectedJob && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-2xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden">
            <div className="p-5 border-b border-slate-800 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-white">Détails du Job : {selectedJob.id}</h3>
                <p className="text-xs text-slate-400">Destinataire : {selectedJob.phone}</p>
              </div>
              <button
                onClick={() => setSelectedJob(null)}
                className="text-slate-400 hover:text-white text-sm"
              >
                ✕
              </button>
            </div>

            <div className="p-6 overflow-y-auto space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3 bg-slate-950 p-4 rounded-xl border border-slate-800">
                <div>
                  <span className="text-slate-500">Statut :</span>
                  <p className="font-bold text-slate-200">{selectedJob.status}</p>
                </div>
                <div>
                  <span className="text-slate-500">Message ID externe :</span>
                  <p className="font-mono text-emerald-400">{selectedJob.external_message_id || '—'}</p>
                </div>
                <div>
                  <span className="text-slate-500">Campagne :</span>
                  <p className="text-slate-200">{selectedJob.campaign_id || 'DEFAULT'}</p>
                </div>
                <div>
                  <span className="text-slate-500">Tentatives :</span>
                  <p className="text-slate-200">{selectedJob.attempts} / {selectedJob.max_attempts}</p>
                </div>
              </div>

              <div>
                <span className="text-slate-400 font-semibold">Message traité :</span>
                <div className="mt-1 p-3.5 bg-slate-950 border border-slate-800 rounded-xl text-slate-200 leading-relaxed">
                  {selectedJob.message}
                </div>
              </div>

              {selectedJob.error_message && (
                <div className="p-3 bg-rose-950/40 border border-rose-800 rounded-xl text-rose-300">
                  <p className="font-bold">Erreur : [{selectedJob.error_code}]</p>
                  <p>{selectedJob.error_message}</p>
                </div>
              )}

              {/* Job Execution Logs */}
              <div>
                <span className="text-slate-400 font-semibold">Historique d'exécution de ce Job :</span>
                <div className="mt-2 space-y-1.5 font-mono text-[11px] max-h-48 overflow-y-auto bg-slate-950 p-3 rounded-xl border border-slate-800">
                  {selectedJobLogs.length === 0 ? (
                    <p className="text-slate-500">Aucun log spécifique enregistré.</p>
                  ) : (
                    selectedJobLogs.map(l => (
                      <div key={l.id} className="text-slate-300">
                        <span className="text-slate-500">{new Date(l.created_at).toLocaleTimeString()}</span>{' '}
                        <span className="text-emerald-400">[{l.event}]</span> {l.message}
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>

            <div className="p-4 border-t border-slate-800 bg-slate-950/50 flex justify-end">
              <button
                onClick={() => setSelectedJob(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold"
              >
                Fermer
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* QUICK SEND MODAL                                              */}
      {/* ------------------------------------------------------------- */}
      {isQuickSendOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden animate-in fade-in zoom-in-95">
            <div className="p-5 bg-gradient-to-r from-emerald-700 to-teal-800 text-white flex items-center justify-between border-b border-emerald-500/30">
              <div className="flex items-center space-x-2.5">
                <div className="p-2 bg-white/15 rounded-xl">
                  <Send className="w-4 h-4 text-white" />
                </div>
                <div>
                  <h3 className="text-sm font-bold">Nouveau Message Automatisé</h3>
                  <p className="text-[11px] text-emerald-100">Ajouter directement un envoi avec Spintax & Anti-Ban</p>
                </div>
              </div>
              <button
                onClick={() => setIsQuickSendOpen(false)}
                className="text-white/80 hover:text-white cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleQuickSend} className="p-5 space-y-3.5 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Numéro (+216 ou intl) :</label>
                  <input
                    type="text"
                    required
                    value={quickPhone}
                    onChange={e => setQuickPhone(e.target.value)}
                    placeholder="+216 98 000 000"
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-emerald-500 font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Nom / Interlocuteur :</label>
                  <input
                    type="text"
                    value={quickName}
                    onChange={e => setQuickName(e.target.value)}
                    placeholder="Nom du prospect ({nom})"
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Identifiant Campagne :</label>
                <input
                  type="text"
                  value={quickCampaign}
                  onChange={e => setQuickCampaign(e.target.value)}
                  placeholder="CAMP_AUDIT_KMS"
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-slate-300 font-semibold">Message (Spintax compatible) :</label>
                  <span className="text-[10px] text-slate-400 font-mono">{'{nom}'} • {'{...|...}'}</span>
                </div>
                <textarea
                  required
                  rows={5}
                  value={quickMessage}
                  onChange={e => setQuickMessage(e.target.value)}
                  className="w-full p-3 rounded-xl bg-slate-950 border border-slate-800 text-slate-100 font-mono leading-relaxed focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800 text-[11px] text-slate-400 flex items-center space-x-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Le worker exécutera cet envoi avec délais aléatoires et simulation de frappe.</span>
              </div>

              <div className="pt-2 flex items-center justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setIsQuickSendOpen(false)}
                  className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold cursor-pointer"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  disabled={actionLoading === 'quick-send'}
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold flex items-center space-x-1.5 shadow-md shadow-emerald-950/40 cursor-pointer border border-emerald-400"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Placer dans la file d'attente</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
export default WhatsAppSenderView;
